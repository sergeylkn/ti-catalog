# CLAUDE.md — Project Brief for Claude Code

## Project
Tubes International — Interactive Catalog with AI Assistant
Built on 186 PDF catalogs of industrial hoses, fittings, valves.

## Critical Architecture Rule
**AI does NOT select products. The structured DB does.**
- Stage B (SQL filter) finds candidates using exact parameters
- Stage D (Compatibility rules) enforces hard exclusions in Python
- Stage F (Claude) only EXPLAINS the results from the DB

## Stack
- Backend: Python 3.12 + FastAPI + SQLAlchemy async + PostgreSQL + pgvector
- Frontend: Next.js 14 + TypeScript + Tailwind CSS
- AI: Anthropic Claude (claude-opus-4-6 for explain, claude-haiku-4-5 for parse/extract)
- PDF: pdfplumber for extraction

## Database
See `backend/schema.sql` for the full PostgreSQL schema.
Key tables:
- `products` — product records with vector embedding
- `product_attributes` — all normalized technical parameters
- `kb_documents` + `kb_chunks` — knowledge base
- `compatibility_rules` — hard exclusion/warning rules

## AI Pipeline (6 Stages)
See `docs/ARCHITECTURE.md` for full diagram.
Code: `backend/app/services/ai_query.py`

## Parameter Normalization Rules
- Pressure: always store in bar (1 PSI = 0.0689 bar)
- Temperature: always store in °C
- Diameter: always store in mm (1 inch = 25.4mm)
- Thread standards: BSP, BSPT, NPT, metric, JIC, DIN, GOST (normalized)
- Materials: EPDM, NBR, PTFE, PVC, Viton, SBR, stainless, brass, polyurethane

## AI Constraints (NEVER violate)
- ✗ Never invent product articles
- ✗ Never invent specifications
- ✗ Never show analog as exact match without 🔴 marker
- ✗ Never mix hydraulics/pneumatics without explicit query
- ✗ Never show accessories instead of main products
- ✓ Always show source: filename + page number
- ✓ Always show confidence: 🟢 EXACT | 🟡 PARTIAL | 🔴 ANALOG

## Development Priority
1. `scripts/pdf_import/importer.py` — get data in first
2. `backend/app/services/structured_search.py` — core search logic
3. `backend/app/services/compatibility.py` — hard rules
4. `backend/app/api/search.py` — expose the API
5. Frontend catalog grid + filters
6. AI chat integration

## Running Locally
```bash
# Backend
cd backend
pip install -r requirements.txt
cp .env.example .env  # fill in DB URL and API key
uvicorn app.main:app --reload --port 8000

# Frontend
cd frontend
npm install
npm run dev  # port 3000

# Import PDFs (put PDFs in ./pdf_catalog/)
python scripts/pdf_import/importer.py ./pdf_catalog/
```
