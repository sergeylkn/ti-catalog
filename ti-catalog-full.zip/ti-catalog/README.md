# Tubes International — Інтерактивний Каталог

Гібридний веб-каталог промислової продукції з AI-помічником.
- **18 000+ товарів** з 186 PDF-каталогів
- **6-стадійний підбір**: SQL-фільтри → правила сумісності → AI-пояснення
- **Захист від галюцинацій**: AI не вигадує — тільки пояснює дані з бази

---

## Швидкий старт (Docker)

```bash
# 1. Клонуйте та перейдіть в папку
git clone ... && cd ti-catalog

# 2. Скопіюйте PDF-файли каталогу
mkdir pdf_catalog
cp /шлях/до/ваших/*.pdf pdf_catalog/

# 3. Налаштуйте змінні середовища
cp .env.example .env
# Відкрийте .env і вставте ANTHROPIC_API_KEY

# 4. Запустіть все одною командою
docker compose up -d

# 5. Відкрийте каталог
open http://localhost:3000

# 6. Відкрийте адмін-панель і запустіть імпорт PDF
open http://localhost:3000/admin
```

---

## Запуск вручну (без Docker)

### Вимоги
- Python 3.12+
- Node.js 20+
- PostgreSQL 16 + pgvector extension

### 1. База даних

```bash
# Встановіть pgvector
psql -c "CREATE EXTENSION vector;"

# Створіть схему
psql -d ti_catalog -f backend/schema.sql
```

### 2. Backend

```bash
cd backend
pip install -r requirements.txt

cp ../.env.example .env
# Заповніть DATABASE_URL і ANTHROPIC_API_KEY

uvicorn app.main:app --reload --port 8000
```

### 3. Frontend

```bash
cd frontend
npm install
echo "NEXT_PUBLIC_API_URL=http://localhost:8000" > .env.local
npm run dev
```

### 4. Імпорт PDF

```bash
# Покладіть PDF у папку:
mkdir pdf_catalog
cp ваші_файли.pdf pdf_catalog/

# Запустіть імпорт через адмін-панель:
open http://localhost:3000/admin
# → натисніть "Запустити імпорт"

# АБО через командний рядок:
python scripts/pdf_import/importer.py ./pdf_catalog/
```

### 5. Збагачення Knowledge Base

```bash
# Після імпорту — збагатити chunks (ключові слова, зв'язки)
python scripts/kb_builder/build_kb.py
```

### 6. Embeddings (для семантичного пошуку)

```bash
# Потрібен OpenAI API key (або закоментуйте — буде тільки SQL-пошук)
export OPENAI_API_KEY=sk-...
python scripts/embeddings/build_embeddings.py all
```

---

## Архітектура

```
Запит користувача
        ↓
A) Claude Haiku — парсинг параметрів (тип, DN, тиск, матеріал)
        ↓
B) PostgreSQL — строгий SQL-пошук за параметрами
        ↓ (якщо < 3 результатів)
C) pgvector — семантичний пошук за embeddings
        ↓
D) Правила сумісності — виключити гідравліку/пневматику/аксесуари
        ↓
E) Reranking — сортування: 🟢 точне → 🟡 часткове → 🔴 аналог
        ↓
F) Claude Opus — пояснення чому підходить (тільки з даних БД)
```

**AI не вигадує товари або характеристики. Всі дані приходять з бази.**

---

## API Endpoints

| Метод | URL | Опис |
|-------|-----|------|
| GET | `/api/search` | Пошук з фільтрами |
| POST | `/api/ai/query` | AI-підбір (6 стадій) |
| GET | `/api/products/:id` | Деталі товару |
| GET | `/api/filters` | Доступні фільтри |
| GET | `/api/kb/search` | Пошук по knowledge base |
| POST | `/api/admin/import` | Запустити імпорт PDF |
| POST | `/api/admin/reindex` | Перебудувати embeddings |

---

## Структура проекту

```
ti-catalog/
├── backend/
│   ├── app/
│   │   ├── api/          — FastAPI роутери
│   │   ├── db/           — SQLAlchemy моделі + сесія
│   │   ├── schemas/      — Pydantic схеми
│   │   └── services/     — Бізнес-логіка (6-стадійний пайплайн)
│   ├── schema.sql        — PostgreSQL схема
│   └── requirements.txt
├── frontend/
│   └── src/
│       ├── app/          — Next.js сторінки
│       ├── components/   — React компоненти
│       └── lib/          — API клієнт
├── scripts/
│   ├── pdf_import/       — Імпорт PDF → БД
│   ├── kb_builder/       — Збагачення Knowledge Base
│   └── embeddings/       — Генерація векторів
├── docker-compose.yml
└── .env.example
```

---

## Адмін-панель

Відкрийте `http://localhost:3000/admin`

- **Імпорт** — завантажити PDF, запустити reindex
- **Товари** — переглянути, відредагувати, позначити "перевірено"
- **PDF** — статус кожного документа
- **Chunks** — переглянути knowledge base chunks

---

## Змінні середовища

| Змінна | Опис | Обов'язково |
|--------|------|-------------|
| `ANTHROPIC_API_KEY` | Ключ Claude API | ✅ |
| `DATABASE_URL` | PostgreSQL підключення | ✅ |
| `PDF_DIR` | Папка з PDF-файлами | ✅ |
| `ADMIN_SECRET` | Пароль адмін-панелі | ✅ |
| `OPENAI_API_KEY` | Для embeddings | ❌ (без нього — тільки SQL-пошук) |
