"""
Admin API endpoints:
- POST /api/admin/import          — trigger PDF import
- GET  /api/admin/documents       — list imported PDFs  
- GET  /api/admin/products        — list products with filters
- PATCH /api/admin/products/:id   — edit product/attributes
- POST /api/admin/reindex         — rebuild embeddings
- GET  /api/admin/import-log      — import history
- GET  /api/admin/chunks          — browse KB chunks
"""

from fastapi import APIRouter, Depends, Header, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pathlib import Path
from uuid import UUID

from app.core.config import settings
from app.db.session import get_db
from app.db.models import Product, ProductAttribute, KBDocument, KBChunk, ImportLog
from scripts.pdf_import.importer import import_all_pdfs

router = APIRouter()


def require_admin(x_admin_secret: str = Header(...)):
    if x_admin_secret != settings.ADMIN_SECRET:
        raise HTTPException(status_code=403, detail="Forbidden")


# ── Import ────────────────────────────────────────────────────────────────────

@router.post("/import")
async def trigger_import(
    background: BackgroundTasks,
    _: None = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Start PDF import in background."""
    pdf_dir = Path(settings.PDF_DIR)
    if not pdf_dir.exists():
        raise HTTPException(400, f"PDF directory not found: {pdf_dir}")

    background.add_task(import_all_pdfs, pdf_dir)
    files = list(pdf_dir.glob("*.pdf"))
    return {"message": "Import started", "pdf_count": len(files)}


@router.get("/import-log")
async def import_log(
    limit: int = 50,
    _: None = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(ImportLog).order_by(ImportLog.started_at.desc()).limit(limit)
    rows = (await db.execute(stmt)).scalars().all()
    return [
        {
            "id": r.id,
            "file": r.file_name,
            "status": r.status,
            "products": r.products_saved,
            "chunks": r.chunks_created,
            "started": str(r.started_at),
            "completed": str(r.completed_at),
            "errors": r.errors,
        }
        for r in rows
    ]


# ── Documents ─────────────────────────────────────────────────────────────────

@router.get("/documents")
async def list_documents(
    status: str | None = None,
    limit: int = 100,
    _: None = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(KBDocument)
    if status:
        stmt = stmt.where(KBDocument.status == status)
    stmt = stmt.order_by(KBDocument.created_at.desc()).limit(limit)
    rows = (await db.execute(stmt)).scalars().all()
    return [
        {
            "id": str(r.id),
            "file_name": r.file_name,
            "status": r.status,
            "pages": r.page_count,
            "indexed_at": str(r.indexed_at),
        }
        for r in rows
    ]


# ── Products ──────────────────────────────────────────────────────────────────

@router.get("/products")
async def list_products(
    q:        str | None = None,
    verified: bool | None = None,
    page:     int = 1,
    limit:    int = 50,
    _: None = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Product)
    if q:
        stmt = stmt.where(Product.name.ilike(f"%{q}%"))
    if verified is not None:
        stmt = stmt.where(Product.verified == verified)
    total_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(total_stmt)).scalar()
    stmt = stmt.offset((page - 1) * limit).limit(limit)
    rows = (await db.execute(stmt)).scalars().all()
    return {
        "total": total,
        "page": page,
        "items": [
            {
                "id": str(r.id),
                "article": r.article,
                "name": r.name,
                "type": r.product_type,
                "source": r.source_file,
                "page": r.source_page,
                "verified": r.verified,
            }
            for r in rows
        ],
    }


@router.patch("/products/{product_id}")
async def update_product(
    product_id: UUID,
    body: dict,
    _: None = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Manually edit product data — mark verified."""
    product = await db.get(Product, product_id)
    if not product:
        raise HTTPException(404, "Product not found")

    allowed_fields = {"name", "article", "sku", "product_type", "brand", "series",
                      "short_description", "verified", "is_active"}
    for k, v in body.items():
        if k in allowed_fields:
            setattr(product, k, v)

    # Also update attributes if provided
    attr_data = body.get("attributes", {})
    if attr_data:
        attrs = (await db.execute(
            select(ProductAttribute).where(ProductAttribute.product_id == product_id)
        )).scalar_one_or_none()
        if attrs:
            attr_fields = {"pressure_max_bar", "temp_min_c", "temp_max_c",
                           "inner_diameter_mm", "outer_diameter_mm",
                           "food_approved", "vacuum_rated", "atex_rated",
                           "material_normalized", "medium_normalized"}
            for k, v in attr_data.items():
                if k in attr_fields:
                    setattr(attrs, k, v)

    await db.commit()
    return {"ok": True}


# ── Chunks ────────────────────────────────────────────────────────────────────

@router.get("/chunks")
async def list_chunks(
    file_name: str | None = None,
    page:      int = 1,
    limit:     int = 50,
    _: None = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(KBChunk)
    if file_name:
        stmt = stmt.where(KBChunk.file_name == file_name)
    stmt = stmt.order_by(KBChunk.file_name, KBChunk.page_number, KBChunk.chunk_index)
    stmt = stmt.offset((page - 1) * limit).limit(limit)
    rows = (await db.execute(stmt)).scalars().all()
    return [
        {
            "id": str(r.id),
            "file": r.file_name,
            "page": r.page_number,
            "type": r.chunk_type,
            "text": r.chunk_text[:300],
            "keywords": r.keywords,
            "products": [str(p) for p in (r.related_product_ids or [])],
        }
        for r in rows
    ]


# ── Reindex ───────────────────────────────────────────────────────────────────

@router.post("/reindex")
async def reindex(
    background: BackgroundTasks,
    mode: str = "all",  # all|products|chunks
    _: None = Depends(require_admin),
):
    """Rebuild embeddings for products and/or KB chunks."""
    from scripts.embeddings.build_embeddings import run_embedding_pipeline
    background.add_task(run_embedding_pipeline, mode)
    return {"message": f"Reindex started (mode={mode})"}
