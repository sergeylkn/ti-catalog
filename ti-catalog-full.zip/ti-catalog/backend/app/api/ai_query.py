"""
AI API router — /api/ai/query
Delegates to AIQueryService (6-stage pipeline).
"""

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
import time

from app.db.session import get_db
from app.services.ai_query import AIQueryService
from app.schemas.search import AIQueryRequest, AIQueryResponse

router = APIRouter()


@router.post("/query", response_model=AIQueryResponse)
async def ai_query(
    body: AIQueryRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Full 6-stage hybrid AI search:
    A) Parse → B) Structured DB → C) Semantic → D) Compat → E) Rerank → F) Explain
    """
    t0 = time.perf_counter()

    service = AIQueryService(db)
    result = await service.query(
        user_query=body.query,
        chat_history=body.history or [],
        session_id=body.session_id or "anon",
    )

    result.took_ms = round((time.perf_counter() - t0) * 1000)
    return result
