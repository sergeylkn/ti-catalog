"""GET /api/filters — available filter values from the database"""

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, distinct
from sqlalchemy.dialects.postgresql import array_agg

from app.db.session import get_db
from app.db.models import Product, ProductAttribute, Category

router = APIRouter()


@router.get("/filters")
async def get_filters(db: AsyncSession = Depends(get_db)):
    """
    Returns all available filter options for the catalog UI.
    Only returns values that actually exist in the database.
    """

    # Product types
    types_result = await db.execute(
        select(Product.product_type)
        .where(Product.product_type != None)
        .where(Product.is_active == True)
        .distinct()
        .order_by(Product.product_type)
    )
    product_types = [r[0] for r in types_result.fetchall()]

    # Categories
    cats_result = await db.execute(
        select(Category.id, Category.name, Category.slug)
        .where(Category.parent_id == None)
        .order_by(Category.sort_order, Category.name)
    )
    categories = [
        {"id": r.id, "name": r.name, "slug": r.slug}
        for r in cats_result.fetchall()
    ]

    # Materials (from normalized array)
    mat_result = await db.execute(
        select(func.unnest(ProductAttribute.material_normalized).label("mat"))
        .distinct()
        .order_by("mat")
    )
    materials = [r[0] for r in mat_result.fetchall() if r[0]]

    # Thread types
    thread_result = await db.execute(
        select(ProductAttribute.thread_type)
        .where(ProductAttribute.thread_type != None)
        .distinct()
        .order_by(ProductAttribute.thread_type)
    )
    thread_types = [r[0] for r in thread_result.fetchall()]

    # Connection types
    conn_result = await db.execute(
        select(ProductAttribute.connection_type)
        .where(ProductAttribute.connection_type != None)
        .distinct()
        .order_by(ProductAttribute.connection_type)
    )
    connection_types = [r[0] for r in conn_result.fetchall()]

    # Pressure range
    p_result = await db.execute(
        select(
            func.min(ProductAttribute.pressure_max_bar),
            func.max(ProductAttribute.pressure_max_bar),
        )
    )
    p_row = p_result.fetchone()
    pressure_range = {
        "min": float(p_row[0]) if p_row[0] else 0,
        "max": float(p_row[1]) if p_row[1] else 500,
    }

    # DN range
    dn_result = await db.execute(
        select(
            func.min(ProductAttribute.inner_diameter_mm),
            func.max(ProductAttribute.inner_diameter_mm),
        )
    )
    dn_row = dn_result.fetchone()
    dn_range = {
        "min": float(dn_row[0]) if dn_row[0] else 4,
        "max": float(dn_row[1]) if dn_row[1] else 300,
    }

    # Temperature range
    t_result = await db.execute(
        select(
            func.min(ProductAttribute.temp_min_c),
            func.max(ProductAttribute.temp_max_c),
        )
    )
    t_row = t_result.fetchone()
    temp_range = {
        "min": float(t_row[0]) if t_row[0] else -60,
        "max": float(t_row[1]) if t_row[1] else 300,
    }

    # Counts
    total_products = (await db.execute(
        select(func.count()).where(Product.is_active == True)
    )).scalar()

    food_count = (await db.execute(
        select(func.count()).join(
            ProductAttribute, ProductAttribute.product_id == Product.id
        ).where(ProductAttribute.food_approved == True)
        .where(Product.is_active == True)
    )).scalar()

    vacuum_count = (await db.execute(
        select(func.count()).join(
            ProductAttribute, ProductAttribute.product_id == Product.id
        ).where(ProductAttribute.vacuum_rated == True)
        .where(Product.is_active == True)
    )).scalar()

    return {
        "total_products":  total_products,
        "categories":      categories,
        "product_types":   product_types,
        "materials":       materials,
        "thread_types":    thread_types,
        "connection_types":connection_types,
        "pressure_range":  pressure_range,
        "dn_range":        dn_range,
        "temp_range":      temp_range,
        "special": {
            "food_approved": food_count,
            "vacuum_rated":  vacuum_count,
        },
    }
