"""
Knowledge Base API router — /api/kb/*
"""

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.services.kb_search import KBSearchService

router = APIRouter()


@router.get("/search")
async def kb_search(
    q:          str = Query(..., min_length=1, description="Search query"),
    limit:      int = Query(default=5, ge=1, le=20),
    chunk_type: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Full-text search across all catalog knowledge base chunks."""
    service = KBSearchService(db)
    chunks = await service.search(q, limit=limit, chunk_type=chunk_type)
    return {
        "query":  q,
        "count":  len(chunks),
        "chunks": [
            {
                "id":           c.id,
                "file_name":    c.file_name,
                "page_number":  c.page_number,
                "section_name": c.section_name,
                "chunk_type":   c.chunk_type,
                "text":         c.chunk_text[:600],
                "keywords":     c.keywords,
                "score":        round(c.score, 4),
            }
            for c in chunks
        ],
    }


@router.get("/by-file")
async def kb_by_file(
    file_name: str = Query(...),
    page:      int | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Get all KB chunks for a specific PDF file (and optionally a page)."""
    service = KBSearchService(db)
    chunks = await service.get_by_file(file_name, page=page)
    return {
        "file_name": file_name,
        "page":      page,
        "count":     len(chunks),
        "chunks": [
            {
                "id":          c.id,
                "page_number": c.page_number,
                "chunk_type":  c.chunk_type,
                "text":        c.chunk_text,
                "keywords":    c.keywords,
            }
            for c in chunks
        ],
    }
