"""GET /api/products/:id — product detail with related products"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from uuid import UUID

from app.db.session import get_db
from app.db.models import Product, ProductAttribute, KBChunk

router = APIRouter()


@router.get("/products/{product_id}")
async def get_product(
    product_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    """Full product detail including attributes, source, and related KB chunks."""
    product = await db.get(Product, product_id)
    if not product or not product.is_active:
        raise HTTPException(404, "Product not found")

    attrs = (await db.execute(
        select(ProductAttribute).where(ProductAttribute.product_id == product_id)
    )).scalar_one_or_none()

    # Related products: same series OR same subsection
    related = []
    if product.series:
        stmt = (
            select(Product)
            .where(Product.series == product.series)
            .where(Product.id != product_id)
            .where(Product.is_active == True)
            .limit(8)
        )
        related_rows = (await db.execute(stmt)).scalars().all()
        related = [
            {"id": str(r.id), "article": r.article, "name": r.name, "type": r.product_type}
            for r in related_rows
        ]

    # KB chunks referencing this product
    kb_stmt = (
        select(KBChunk)
        .where(KBChunk.file_name == product.source_file)
        .where(KBChunk.page_number == product.source_page)
        .limit(3)
    )
    kb_chunks = (await db.execute(kb_stmt)).scalars().all()

    return {
        "id": str(product.id),
        "article": product.article,
        "sku": product.sku,
        "name": product.name,
        "product_type": product.product_type,
        "brand": product.brand,
        "series": product.series,
        "short_description": product.short_description,
        "full_description": product.full_description,
        "source_file": product.source_file,
        "source_page": product.source_page,
        "source_section": product.source_section,
        "verified": product.verified,
        "attributes": _attrs_dict(attrs),
        "related": related,
        "kb_chunks": [
            {
                "file": c.file_name,
                "page": c.page_number,
                "type": c.chunk_type,
                "text": c.chunk_text[:400],
            }
            for c in kb_chunks
        ],
    }


def _attrs_dict(a: ProductAttribute | None) -> dict:
    if not a:
        return {}
    return {
        "pressure_max_bar":   a.pressure_max_bar,
        "pressure_min_bar":   a.pressure_min_bar,
        "pressure_raw":       a.pressure_raw,
        "temp_min_c":         a.temp_min_c,
        "temp_max_c":         a.temp_max_c,
        "temp_raw":           a.temp_raw,
        "inner_diameter_mm":  a.inner_diameter_mm,
        "outer_diameter_mm":  a.outer_diameter_mm,
        "diameter_raw":       a.diameter_raw,
        "diameter_inch":      a.diameter_inch,
        "thread_type":        a.thread_type,
        "thread_size_raw":    a.thread_size_raw,
        "connection_type":    a.connection_type,
        "standard":           a.standard,
        "medium":             a.medium,
        "medium_normalized":  a.medium_normalized or [],
        "material_inner":     a.material_inner,
        "material_normalized":a.material_normalized or [],
        "food_approved":      a.food_approved,
        "vacuum_rated":       a.vacuum_rated,
        "atex_rated":         a.atex_rated,
        "ce_certified":       a.ce_certified,
        "length_mm":          a.length_mm,
        "weight_kg":          a.weight_kg,
        "extra":              a.extra or {},
    }
