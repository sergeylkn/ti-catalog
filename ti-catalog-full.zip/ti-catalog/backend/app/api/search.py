"""
/api/search — Main search endpoint
/api/ai/query — AI-assisted search endpoint
"""

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
import time

from app.db.session import get_db
from app.services.ai_query import AIQueryService
from app.services.structured_search import StructuredSearchService
from app.services.kb_search import KBSearchService
from app.schemas.search import (
    SearchRequest, AIQueryRequest,
    SearchResponse, AIQueryResponse,
    ParsedQuery,
)

router = APIRouter()


@router.get("/search", response_model=SearchResponse)
async def search(
    q:         str   = Query(..., min_length=1, description="Search query"),
    category:  Optional[str]   = None,
    material:  Optional[str]   = None,
    dn_min:    Optional[float] = None,
    dn_max:    Optional[float] = None,
    p_min:     Optional[float] = None,
    t_min:     Optional[float] = None,
    t_max:     Optional[float] = None,
    food:      Optional[bool]  = None,
    vacuum:    Optional[bool]  = None,
    page:      int   = Query(default=1, ge=1),
    page_size: int   = Query(default=24, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """
    Structured catalog search with filters.
    No AI involved — pure database search.
    """
    t0 = time.perf_counter()

    parsed = ParsedQuery(
        product_type=category,
        material=material,
        inner_diameter_mm=dn_min,  # simplified
        min_pressure_bar=p_min,
        temp_min_c=t_min,
        temp_max_c=t_max,
        food_approved=food,
        vacuum_rated=vacuum,
        search_mode="exact",
        confidence=0.9,
    )

    service = StructuredSearchService(db)
    all_results = await service.search(parsed)

    # Pagination
    total = len(all_results)
    start = (page - 1) * page_size
    items = all_results[start:start + page_size]

    return SearchResponse(
        query=q,
        total=total,
        page=page,
        page_size=page_size,
        results=items,
        took_ms=round((time.perf_counter() - t0) * 1000),
    )


@router.post("/ai/query", response_model=AIQueryResponse)
async def ai_query(
    body: AIQueryRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Full 6-stage AI-assisted hybrid search:
    A) Parse → B) Structured DB → C) Semantic → D) Compat → E) Rerank → F) Explain
    """
    t0 = time.perf_counter()

    service = AIQueryService(db)
    result = await service.query(
        user_query=body.query,
        chat_history=body.history or [],
        session_id=body.session_id or "anon",
    )

    result.took_ms = round((time.perf_counter() - t0) * 1000)
    return result


@router.get("/kb/search")
async def kb_search(
    q:     str = Query(..., description="Knowledge base query"),
    limit: int = Query(default=5, ge=1, le=20),
    db: AsyncSession = Depends(get_db),
):
    """
    Knowledge base text search.
    Returns relevant chunks from catalog PDFs.
    """
    service = KBSearchService(db)
    chunks = await service.search(q, limit=limit)
    return {
        "query": q,
        "chunks": [
            {
                "id": str(c.id),
                "file_name": c.file_name,
                "page_number": c.page_number,
                "section_name": c.section_name,
                "chunk_type": c.chunk_type,
                "text": c.chunk_text[:500],
                "keywords": c.keywords,
            }
            for c in chunks
        ],
    }
