from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # App
    APP_NAME: str = "Tubes International Catalog"
    DEBUG: bool = False

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postgres:password@localhost:5432/ti_catalog"

    # Anthropic
    ANTHROPIC_API_KEY: str = ""
    AI_MODEL: str = "claude-opus-4-6"
    AI_MAX_TOKENS: int = 4000

    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:3001"]

    # PDF Storage
    PDF_DIR: str = "./pdf_catalog"
    CHUNK_SIZE: int = 800         # characters per chunk
    CHUNK_OVERLAP: int = 100

    # Search
    SEMANTIC_RECALL_THRESHOLD: float = 0.72  # cosine similarity min
    MAX_STRUCTURED_RESULTS: int = 50
    MAX_SEMANTIC_RESULTS: int = 20
    MAX_KB_CHUNKS: int = 5        # chunks sent to AI for context

    # Admin
    ADMIN_SECRET: str = "change-me-in-production"

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
