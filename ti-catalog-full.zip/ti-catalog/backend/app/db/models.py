"""SQLAlchemy ORM models matching schema.sql"""

from __future__ import annotations
import uuid
from datetime import datetime
from typing import Optional
from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey,
    Integer, String, Text, ARRAY, BigInteger, func
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import DeclarativeBase, relationship
from pgvector.sqlalchemy import Vector


class Base(DeclarativeBase):
    pass


class Category(Base):
    __tablename__ = "categories"

    id          = Column(Integer, primary_key=True)
    parent_id   = Column(Integer, ForeignKey("categories.id"), nullable=True)
    name        = Column(String(200), nullable=False)
    slug        = Column(String(200), unique=True, nullable=False)
    description = Column(Text)
    sort_order  = Column(Integer, default=0)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())

    children    = relationship("Category", backref="parent", remote_side=[id])
    products    = relationship("Product", foreign_keys="Product.category_id", back_populates="category")


class Product(Base):
    __tablename__ = "products"

    id                = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sku               = Column(String(100), index=True)
    article           = Column(String(100), index=True)
    name              = Column(String(500), nullable=False)
    category_id       = Column(Integer, ForeignKey("categories.id"))
    subcategory_id    = Column(Integer, ForeignKey("categories.id"))
    product_type      = Column(String(100), index=True)
    brand             = Column(String(100))
    series            = Column(String(100), index=True)
    short_description = Column(Text)
    full_description  = Column(Text)

    source_file       = Column(String(300))
    source_page       = Column(Integer)
    source_section    = Column(String(200))
    raw_text_fragment = Column(Text)

    verified   = Column(Boolean, default=False)
    is_active  = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    embedding  = Column(Vector(1536))

    category    = relationship("Category", foreign_keys=[category_id], back_populates="products")
    subcategory = relationship("Category", foreign_keys=[subcategory_id])
    attributes  = relationship("ProductAttribute", back_populates="product",
                               uselist=False, cascade="all, delete-orphan")


class ProductAttribute(Base):
    __tablename__ = "product_attributes"

    id         = Column(Integer, primary_key=True)
    product_id = Column(UUID(as_uuid=True), ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)

    # Pressure
    pressure_max_bar = Column(Float)
    pressure_min_bar = Column(Float)
    pressure_raw     = Column(String(100))

    # Temperature
    temp_min_c = Column(Float)
    temp_max_c = Column(Float)
    temp_raw   = Column(String(100))

    # Diameter
    inner_diameter_mm = Column(Float, index=True)
    outer_diameter_mm = Column(Float)
    diameter_raw      = Column(String(100))
    diameter_inch     = Column(String(20))

    # Thread / Connection
    thread_type     = Column(String(50), index=True)
    thread_size_raw = Column(String(100))
    connection_type = Column(String(100))
    standard        = Column(String(100))

    # Medium
    medium            = Column(String(200))
    medium_normalized = Column(ARRAY(String(50)))

    # Materials
    material_inner      = Column(String(200))
    material_outer      = Column(String(200))
    material_fittings   = Column(String(200))
    material_normalized = Column(ARRAY(String(50)))

    # Physical
    length_mm  = Column(Float)
    length_raw = Column(String(100))
    weight_kg  = Column(Float)
    weight_raw = Column(String(100))

    # Flags
    food_approved = Column(Boolean, default=False)
    vacuum_rated  = Column(Boolean, default=False)
    atex_rated    = Column(Boolean, default=False)
    ce_certified  = Column(Boolean, default=False)

    extra = Column(JSONB, default=dict)

    product = relationship("Product", back_populates="attributes")


class CompatibilityRule(Base):
    __tablename__ = "compatibility_rules"

    id          = Column(Integer, primary_key=True)
    name        = Column(String(200), nullable=False)
    description = Column(Text)
    rule_type   = Column(String(50), nullable=False)
    priority    = Column(Integer, default=50)
    condition   = Column(JSONB, nullable=False)
    action      = Column(JSONB, nullable=False)
    is_active   = Column(Boolean, default=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())


class KBDocument(Base):
    __tablename__ = "kb_documents"

    id              = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    file_name       = Column(String(300), nullable=False, unique=True, index=True)
    title           = Column(String(500))
    section         = Column(String(200))
    category_name   = Column(String(200))
    page_count      = Column(Integer)
    file_size_bytes = Column(BigInteger)
    extracted_text  = Column(Text)
    status          = Column(String(50), default="pending", index=True)
    error_msg       = Column(Text)
    indexed_at      = Column(DateTime(timezone=True))
    created_at      = Column(DateTime(timezone=True), server_default=func.now())

    chunks = relationship("KBChunk", back_populates="document", cascade="all, delete-orphan")


class KBChunk(Base):
    __tablename__ = "kb_chunks"

    id           = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_id  = Column(UUID(as_uuid=True), ForeignKey("kb_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    file_name    = Column(String(300), nullable=False, index=True)
    page_number  = Column(Integer)
    section_name = Column(String(300))
    category_name= Column(String(200))
    chunk_index  = Column(Integer)

    chunk_text    = Column(Text, nullable=False)
    chunk_summary = Column(Text)
    keywords      = Column(ARRAY(String))
    chunk_type    = Column(String(50))

    char_count     = Column(Integer)
    token_estimate = Column(Integer)

    embedding = Column(Vector(1536))

    related_product_ids = Column(ARRAY(UUID(as_uuid=True)))

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    document = relationship("KBDocument", back_populates="chunks")


class ImportLog(Base):
    __tablename__ = "import_log"

    id             = Column(Integer, primary_key=True)
    file_name      = Column(String(300))
    status         = Column(String(50))
    products_found = Column(Integer, default=0)
    products_saved = Column(Integer, default=0)
    chunks_created = Column(Integer, default=0)
    errors         = Column(JSONB, default=list)
    started_at     = Column(DateTime(timezone=True), server_default=func.now())
    completed_at   = Column(DateTime(timezone=True))


class SearchLog(Base):
    __tablename__ = "search_log"

    id            = Column(Integer, primary_key=True)
    session_id    = Column(String(100), index=True)
    query_text    = Column(Text)
    parsed_params = Column(JSONB)
    mode          = Column(String(20))
    results_count = Column(Integer)
    confidence    = Column(Float)
    response_ms   = Column(Integer)
    created_at    = Column(DateTime(timezone=True), server_default=func.now(), index=True)
