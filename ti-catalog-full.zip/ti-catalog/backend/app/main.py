"""
Tubes International — Interactive Catalog API
FastAPI backend with hybrid search: structured DB + knowledge base + AI
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.api import search, products, filters, ai_query, kb, admin
from app.core.config import settings
from app.db.session import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(
    title="Tubes International Catalog API",
    version="1.0.0",
    description="Hybrid product catalog: structured DB + knowledge base + AI assistant",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(search.router,   prefix="/api",   tags=["search"])
app.include_router(products.router, prefix="/api",   tags=["products"])
app.include_router(filters.router,  prefix="/api",   tags=["filters"])
app.include_router(ai_query.router, prefix="/api/ai",tags=["ai"])
app.include_router(kb.router,       prefix="/api/kb", tags=["knowledge-base"])
app.include_router(admin.router,    prefix="/api/admin", tags=["admin"])


@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}
