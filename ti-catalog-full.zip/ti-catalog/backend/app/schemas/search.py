from __future__ import annotations
from enum import Enum
from typing import Optional, Any
from uuid import UUID
from pydantic import BaseModel, Field


class ConfidenceLevel(str, Enum):
    EXACT   = "🟢"   # All parameters match
    PARTIAL = "🟡"   # Most parameters match
    ANALOG  = "🔴"   # Functionally similar, some deviations


class ParsedQuery(BaseModel):
    """Output of Stage A — AI parameter extraction."""
    product_type:       Optional[str]   = None  # hose|fitting|valve|hydraulics|pneumatics|...
    medium:             Optional[str]   = None
    min_pressure_bar:   Optional[float] = None
    inner_diameter_mm:  Optional[float] = None
    temp_min_c:         Optional[float] = None
    temp_max_c:         Optional[float] = None
    material:           Optional[str]   = None
    thread_type:        Optional[str]   = None
    connection_type:    Optional[str]   = None
    standard:           Optional[str]   = None
    food_approved:      Optional[bool]  = None
    vacuum_rated:       Optional[bool]  = None
    atex_rated:         Optional[bool]  = None
    search_mode:        str = "exact"    # exact|analog|reference|navigation
    confidence:         float = 0.5
    missing_params:     list[str] = Field(default_factory=list)
    clarification_needed: Optional[str] = None

    def dict(self, **kwargs):
        kwargs.setdefault("exclude_none", False)
        return super().model_dump(**kwargs)


class SearchResult(BaseModel):
    """A single product result with scoring metadata."""
    product_id:         UUID
    article:            Optional[str] = None
    name:               str
    product_type:       Optional[str] = None
    brand:              Optional[str] = None
    series:             Optional[str] = None

    # Key parameters
    inner_diameter_mm:  Optional[float] = None
    outer_diameter_mm:  Optional[float] = None
    pressure_max_bar:   Optional[float] = None
    temp_min_c:         Optional[float] = None
    temp_max_c:         Optional[float] = None
    material_normalized: list[str] = Field(default_factory=list)
    food_approved:      bool = False
    vacuum_rated:       bool = False
    thread_type:        Optional[str] = None
    connection_type:    Optional[str] = None

    # Source
    source_file:        Optional[str] = None
    source_page:        Optional[int] = None

    # Scoring
    confidence_level:   ConfidenceLevel = ConfidenceLevel.ANALOG
    relevance_score:    float = 0.0
    why_fits:           str = "—"
    warnings:           list[str] = Field(default_factory=list)

    class Config:
        use_enum_values = False


class KBChunkResult(BaseModel):
    id:           str
    file_name:    str
    page_number:  Optional[int] = None
    section_name: Optional[str] = None
    chunk_type:   Optional[str] = None
    chunk_text:   str
    keywords:     list[str] = Field(default_factory=list)
    score:        float = 0.0


class SearchRequest(BaseModel):
    q:          str
    category:   Optional[str]   = None
    material:   Optional[str]   = None
    dn_min:     Optional[float] = None
    dn_max:     Optional[float] = None
    p_min:      Optional[float] = None
    t_min:      Optional[float] = None
    t_max:      Optional[float] = None
    food:       Optional[bool]  = None
    vacuum:     Optional[bool]  = None
    page:       int = 1
    page_size:  int = 24


class SearchResponse(BaseModel):
    query:      str
    total:      int
    page:       int
    page_size:  int
    results:    list[SearchResult]
    took_ms:    int = 0


class AIQueryRequest(BaseModel):
    query:      str = Field(..., min_length=1)
    history:    list[dict[str, Any]] = Field(default_factory=list)
    session_id: Optional[str] = None


class AIQueryResponse(BaseModel):
    mode:           str         # exact|analog|reference|navigation|clarification
    parsed:         Optional[ParsedQuery] = None
    results:        list[SearchResult] = Field(default_factory=list)
    kb_chunks:      list[KBChunkResult] = Field(default_factory=list)
    html_response:  str = ""
    confidence:     float = 0.0
    took_ms:        int = 0
