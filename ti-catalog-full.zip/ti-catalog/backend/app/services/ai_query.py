"""
AI Query Service — 6-stage hybrid search pipeline
Stage A: Parse query → structured parameters
Stage B: Structured DB search with strict filters
Stage C: Semantic recall (embeddings) if few results
Stage D: Compatibility rules enforcement
Stage E: Reranking by relevance
Stage F: AI explanation generation
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Optional
import anthropic
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.services.structured_search import StructuredSearchService
from app.services.semantic_search import SemanticSearchService
from app.services.kb_search import KBSearchService
from app.services.compatibility import CompatibilityService
from app.services.reranker import Reranker
from app.schemas.search import (
    ParsedQuery, SearchResult, AIQueryResponse, ConfidenceLevel
)

logger = logging.getLogger(__name__)
ai_client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)


PARSE_SYSTEM = """You are a technical parameter extractor for an industrial hose and fittings catalog.

Extract ONLY parameters explicitly stated or strongly implied in the user query.
NEVER invent or assume parameters not mentioned.
Output ONLY valid JSON. No explanation, no markdown.

Output format:
{
  "product_type": "hose|fitting|valve|compensator|gauge|hydraulics|pneumatics|accessory|null",
  "medium": "air|water|oil|steam|food|acid|fuel|gas|chemical|null",
  "min_pressure_bar": number_or_null,
  "inner_diameter_mm": number_or_null,
  "temp_min_c": number_or_null,
  "temp_max_c": number_or_null,
  "material": "EPDM|NBR|PTFE|PVC|Viton|SBR|stainless|brass|polyurethane|silicone|null",
  "thread_type": "BSP|BSPT|NPT|metric|JIC|DIN|GOST|null",
  "connection_type": "CAMLOCK|Storz|TW|Guillemin|flanged|threaded|null",
  "food_approved": true_or_false_or_null,
  "vacuum_rated": true_or_false_or_null,
  "atex_rated": true_or_false_or_null,
  "standard": "string_or_null",
  "search_mode": "exact|analog|reference|navigation",
  "confidence": 0.0_to_1.0,
  "missing_params": ["list of params that would help narrow the search"],
  "clarification_needed": "null or single clarifying question in the query language"
}"""

EXPLAIN_SYSTEM = """You are a senior technical consultant at Tubes International.
Your job: explain WHY the found products match the user request.

Rules:
- Use ONLY data provided in the context (products + knowledge base)
- NEVER invent specifications or article codes
- If a product is an analog (not exact), clearly mark it as "АНАЛОГ" / "ANALOG"
- Respond in the SAME language as the user query
- Be concise and technical

Response format (HTML allowed):
<div class="ai-answer">
  <div class="ai-mode-badge ai-mode-{a|b|c}">
    {🎯 Підбір | 📚 Довідка | 🗺 Навігація}
  </div>
  <p>1-2 sentences: what was found and why.</p>
  
  <table class="ai-table">
    <thead><tr>
      <th>Match</th><th>Article</th><th>Name</th><th>DN</th><th>P max</th><th>Temp</th><th>Material</th><th>Why it fits</th>
    </tr></thead>
    <tbody>
      [rows — use ONLY data from context]
    </tbody>
  </table>

  <div class="ai-rec-block">
    <span class="ai-rec-icon">✅</span>
    <div><b>Best choice:</b> <div>[article + specific reason]</div></div>
  </div>
  <div class="ai-rec-block">
    <span class="ai-rec-icon">⚠️</span>
    <div><b>Important:</b> <div>[technical caveats, installation notes]</div></div>
  </div>
</div>

Match column values: 🟢 (exact) | 🟡 (partial) | 🔴 (analog)
NEVER put HTML tags inside TD cells. Text only in cells."""


@dataclass
class AIQueryService:
    db: AsyncSession
    structured: StructuredSearchService = field(default=None)
    semantic:   SemanticSearchService   = field(default=None)
    kb:         KBSearchService         = field(default=None)
    compat:     CompatibilityService    = field(default=None)
    reranker:   Reranker               = field(default=None)

    def __post_init__(self):
        self.structured = StructuredSearchService(self.db)
        self.semantic   = SemanticSearchService(self.db)
        self.kb         = KBSearchService(self.db)
        self.compat     = CompatibilityService(self.db)
        self.reranker   = Reranker()

    async def query(
        self,
        user_query: str,
        chat_history: list[dict],
        session_id: str,
    ) -> AIQueryResponse:
        """
        Full 6-stage hybrid search pipeline.
        """
        # ── STAGE A: Parse query ────────────────────────────────────────
        parsed = await self._parse_query(user_query, chat_history)
        logger.info(f"Parsed: {parsed}")

        # If AI needs clarification before searching
        if parsed.clarification_needed:
            return AIQueryResponse(
                mode="clarification",
                parsed=parsed,
                results=[],
                kb_chunks=[],
                html_response=f"<p>{parsed.clarification_needed}</p>",
                confidence=parsed.confidence,
            )

        # ── STAGE B: Structured search ──────────────────────────────────
        structured_results = await self.structured.search(parsed)
        logger.info(f"Structured results: {len(structured_results)}")

        # ── STAGE C: Semantic recall if too few results ─────────────────
        if len(structured_results) < 3 and parsed.confidence > 0.3:
            semantic_results = await self.semantic.recall(user_query, parsed)
            # Merge, deduplicate
            seen = {r.product_id for r in structured_results}
            for r in semantic_results:
                if r.product_id not in seen:
                    r.confidence_level = ConfidenceLevel.ANALOG
                    structured_results.append(r)
                    seen.add(r.product_id)

        # ── STAGE D: Compatibility rules ────────────────────────────────
        filtered = await self.compat.apply(parsed, structured_results)

        # ── STAGE E: Reranking ──────────────────────────────────────────
        ranked = self.reranker.rank(parsed, filtered)[:settings.MAX_STRUCTURED_RESULTS]

        # ── KB search for reference mode or to enrich context ──────────
        kb_chunks = []
        if parsed.search_mode in ("reference", "navigation") or len(ranked) < 2:
            kb_chunks = await self.kb.search(user_query, limit=settings.MAX_KB_CHUNKS)

        # ── STAGE F: AI explanation ─────────────────────────────────────
        html_response = await self._explain(
            user_query=user_query,
            parsed=parsed,
            results=ranked,
            kb_chunks=kb_chunks,
            chat_history=chat_history,
        )

        return AIQueryResponse(
            mode=parsed.search_mode,
            parsed=parsed,
            results=ranked,
            kb_chunks=kb_chunks,
            html_response=html_response,
            confidence=parsed.confidence,
        )

    async def _parse_query(
        self,
        user_query: str,
        chat_history: list[dict],
    ) -> ParsedQuery:
        """Stage A — use Claude to extract structured parameters."""
        messages = [
            *chat_history[-4:],  # last 2 turns for context
            {"role": "user", "content": f"Extract parameters from this query:\n{user_query}"}
        ]
        try:
            resp = ai_client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=500,
                system=PARSE_SYSTEM,
                messages=messages,
            )
            raw = resp.content[0].text.strip()
            # Clean up any accidental markdown fencing
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            data = json.loads(raw)
            return ParsedQuery(**data)
        except Exception as e:
            logger.warning(f"Parse failed: {e}, falling back to empty params")
            return ParsedQuery(
                search_mode="analog",
                confidence=0.4,
                missing_params=["all parameters"],
            )

    async def _explain(
        self,
        user_query: str,
        parsed: ParsedQuery,
        results: list[SearchResult],
        kb_chunks: list,
        chat_history: list[dict],
    ) -> str:
        """Stage F — Claude generates the explanation HTML."""

        # Build context for AI
        ctx_parts = []

        # Parsed parameters
        ctx_parts.append("=== EXTRACTED PARAMETERS ===")
        ctx_parts.append(json.dumps(parsed.dict(exclude_none=True), ensure_ascii=False, indent=2))

        # Product results
        if results:
            ctx_parts.append(f"\n=== FOUND PRODUCTS ({len(results)}) ===")
            ctx_parts.append("Match|Article|Name|DN mm|P max bar|T min|T max|Material|Food|Vacuum|Source")
            for r in results[:25]:
                ctx_parts.append("|".join([
                    r.confidence_level.value,
                    r.article or "—",
                    (r.name or "")[:60],
                    str(r.inner_diameter_mm or "?"),
                    str(r.pressure_max_bar or "?"),
                    str(r.temp_min_c or "?"),
                    str(r.temp_max_c or "?"),
                    (r.material_normalized and ",".join(r.material_normalized)) or "?",
                    "FOOD" if r.food_approved else "",
                    "VAC"  if r.vacuum_rated  else "",
                    f"{r.source_file or ''}:{r.source_page or ''}",
                ]))
        else:
            ctx_parts.append("\n=== NO PRODUCTS FOUND ===")
            ctx_parts.append("Be honest: say nothing was found in the database.")
            ctx_parts.append("Do NOT invent products or specifications.")

        # KB chunks
        if kb_chunks:
            ctx_parts.append(f"\n=== CATALOG KNOWLEDGE BASE ({len(kb_chunks)} fragments) ===")
            for chunk in kb_chunks:
                ctx_parts.append(
                    f"[SOURCE: {chunk.file_name} p.{chunk.page_number}]\n{chunk.chunk_text[:600]}"
                )

        context = "\n".join(ctx_parts)

        messages = [
            *chat_history[-6:],
            {"role": "user", "content": f"{user_query}\n\n{context}"}
        ]

        try:
            resp = ai_client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=settings.AI_MAX_TOKENS,
                system=EXPLAIN_SYSTEM,
                messages=messages,
            )
            return resp.content[0].text
        except Exception as e:
            logger.error(f"AI explain failed: {e}")
            return f"<p>⚠ AI service error. Found {len(results)} products in database.</p>"
