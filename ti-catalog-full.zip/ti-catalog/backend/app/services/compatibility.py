"""
Compatibility Rules Service — Stage D of the pipeline
Enforces hard rules that no AI can override:
- No hydraulics returned for pneumatics queries
- No fittings returned for hose queries
- No products with insufficient pressure
- No accessories instead of main products
"""

import logging
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.search import ParsedQuery, SearchResult, ConfidenceLevel

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# HARD EXCLUSION RULES — these are never relaxed
# Format: (condition_on_query, condition_on_product, reason)
# ═══════════════════════════════════════════════════════════════════════════════

HARD_EXCLUSION_RULES = [
    # Don't return hydraulic products for pneumatic queries
    {
        "name": "no_hydraulics_for_pneumatics",
        "query_match": lambda p: p.product_type == "pneumatics",
        "product_exclude": lambda r: "гідравл" in (r.product_type or "").lower() or
                                     "hydraul"  in (r.product_type or "").lower(),
        "reason": "Гідравліка ≠ пневматика",
    },
    # Don't return pneumatic products for hydraulic queries
    {
        "name": "no_pneumatics_for_hydraulics",
        "query_match": lambda p: p.product_type == "hydraulics",
        "product_exclude": lambda r: "пневм" in (r.product_type or "").lower() or
                                     "pneumat" in (r.product_type or "").lower(),
        "reason": "Пневматика ≠ гідравліка",
    },
    # Don't return compensators for hose queries
    {
        "name": "no_compensators_for_hoses",
        "query_match": lambda p: p.product_type == "hose",
        "product_exclude": lambda r: "компенсат" in (r.product_type or "").lower(),
        "reason": "Компенсатор ≠ шланг",
    },
    # Don't return accessories when main product is requested
    {
        "name": "no_accessories_for_main_product",
        "query_match": lambda p: p.product_type in ("hose", "fitting", "valve", "hydraulics", "pneumatics"),
        "product_exclude": lambda r: "аксесу" in (r.product_type or "").lower() or
                                     "accessor" in (r.product_type or "").lower(),
        "reason": "Аксесуар ≠ основний продукт",
    },
]

# ═══════════════════════════════════════════════════════════════════════════════
# WARNING RULES — product shown but flagged
# ═══════════════════════════════════════════════════════════════════════════════

WARNING_RULES = [
    # Different thread standards
    {
        "name": "thread_mismatch",
        "query_match": lambda p: p.thread_type is not None,
        "product_warn": lambda p, r: (
            r.thread_type is not None and
            r.thread_type.upper() != p.thread_type.upper()
        ),
        "warning": "Різні стандарти різьби — перевірте сумісність",
    },
    # Pressure not known
    {
        "name": "pressure_unknown",
        "query_match": lambda p: p.min_pressure_bar is not None,
        "product_warn": lambda p, r: r.pressure_max_bar is None,
        "warning": "Максимальний тиск не вказаний в каталозі — уточніть у постачальника",
    },
]


class CompatibilityService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def apply(
        self,
        parsed: ParsedQuery,
        results: list[SearchResult],
    ) -> list[SearchResult]:
        """
        Apply all compatibility rules.
        Hard exclusions remove products.
        Warnings are added to the product notes.
        """
        filtered = []

        for result in results:
            # Check hard exclusion rules
            excluded = False
            for rule in HARD_EXCLUSION_RULES:
                try:
                    if rule["query_match"](parsed) and rule["product_exclude"](result):
                        logger.debug(
                            f"Excluded {result.article}: {rule['name']} — {rule['reason']}"
                        )
                        excluded = True
                        break
                except Exception:
                    pass

            if excluded:
                continue

            # Check pressure hard limit (most critical rule)
            if (
                parsed.min_pressure_bar is not None
                and result.pressure_max_bar is not None
                and result.pressure_max_bar < parsed.min_pressure_bar
            ):
                logger.debug(
                    f"Excluded {result.article}: insufficient pressure "
                    f"{result.pressure_max_bar} < {parsed.min_pressure_bar}"
                )
                # Don't exclude — downgrade to ANALOG and add warning
                result.confidence_level = ConfidenceLevel.ANALOG
                result.why_fits += f" ⚠ Тиск {result.pressure_max_bar}бар < {parsed.min_pressure_bar}бар"

            # Apply warning rules
            for rule in WARNING_RULES:
                try:
                    if rule["query_match"](parsed) and rule["product_warn"](parsed, result):
                        if not hasattr(result, "warnings"):
                            result.warnings = []
                        result.warnings.append(rule["warning"])
                except Exception:
                    pass

            filtered.append(result)

        excluded_count = len(results) - len(filtered)
        if excluded_count:
            logger.info(f"Compatibility: excluded {excluded_count}/{len(results)} products")

        return filtered
