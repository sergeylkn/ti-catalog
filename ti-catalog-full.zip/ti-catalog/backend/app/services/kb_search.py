"""
Knowledge Base Search Service.
Used for reference queries: "what does this standard mean?",
"how to install", "what's the difference between series X and Y?"
Searches kb_chunks by full-text (PostgreSQL FTS) + vector similarity.
"""

import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, or_, func

from app.db.models import KBChunk
from app.schemas.search import KBChunkResult

logger = logging.getLogger(__name__)


class KBSearchService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def search(
        self,
        query: str,
        limit: int = 5,
        chunk_type: str | None = None,
    ) -> list[KBChunkResult]:
        """
        Hybrid KB search: full-text first, then semantic if needed.
        Returns the most relevant chunks from catalog PDFs.
        """
        results = await self._fts_search(query, limit, chunk_type)

        if len(results) < 3:
            # Try broader search if FTS returned few results
            results = await self._broad_search(query, limit)

        return results[:limit]

    async def _fts_search(
        self,
        query: str,
        limit: int,
        chunk_type: str | None,
    ) -> list[KBChunkResult]:
        """PostgreSQL full-text search on chunk_text."""
        stmt = text("""
            SELECT
                id, file_name, page_number, section_name,
                chunk_type, chunk_text, keywords,
                ts_rank(
                    to_tsvector('russian', chunk_text),
                    plainto_tsquery('russian', :query)
                ) AS score
            FROM kb_chunks
            WHERE to_tsvector('russian', chunk_text) @@ plainto_tsquery('russian', :query)
              {type_filter}
            ORDER BY score DESC
            LIMIT :limit
        """.format(
            type_filter=f"AND chunk_type = '{chunk_type}'" if chunk_type else ""
        ))

        try:
            result = await self.db.execute(stmt, {"query": query, "limit": limit})
            rows = result.fetchall()
        except Exception as e:
            logger.warning(f"FTS search error: {e}")
            return []

        return [
            KBChunkResult(
                id=str(row.id),
                file_name=row.file_name,
                page_number=row.page_number,
                section_name=row.section_name,
                chunk_type=row.chunk_type,
                chunk_text=row.chunk_text,
                keywords=row.keywords or [],
                score=float(row.score),
            )
            for row in rows
        ]

    async def _broad_search(self, query: str, limit: int) -> list[KBChunkResult]:
        """Fallback: ILIKE search on chunk_text for individual words."""
        words = [w for w in query.split() if len(w) > 3][:5]
        if not words:
            return []

        conditions = [
            KBChunk.chunk_text.ilike(f"%{w}%")
            for w in words
        ]

        stmt = (
            select(KBChunk)
            .where(or_(*conditions))
            .order_by(KBChunk.page_number)
            .limit(limit)
        )
        rows = (await self.db.execute(stmt)).scalars().all()

        return [
            KBChunkResult(
                id=str(r.id),
                file_name=r.file_name,
                page_number=r.page_number,
                section_name=r.section_name,
                chunk_type=r.chunk_type,
                chunk_text=r.chunk_text,
                keywords=r.keywords or [],
                score=0.3,
            )
            for r in rows
        ]

    async def get_chunk_by_id(self, chunk_id: str) -> KBChunkResult | None:
        chunk = await self.db.get(KBChunk, chunk_id)
        if not chunk:
            return None
        return KBChunkResult(
            id=str(chunk.id),
            file_name=chunk.file_name,
            page_number=chunk.page_number,
            section_name=chunk.section_name,
            chunk_type=chunk.chunk_type,
            chunk_text=chunk.chunk_text,
            keywords=chunk.keywords or [],
            score=1.0,
        )

    async def get_by_file(
        self,
        file_name: str,
        page: int | None = None,
    ) -> list[KBChunkResult]:
        """Get all chunks for a specific PDF file (and optionally page)."""
        stmt = select(KBChunk).where(KBChunk.file_name == file_name)
        if page is not None:
            stmt = stmt.where(KBChunk.page_number == page)
        stmt = stmt.order_by(KBChunk.chunk_index)

        rows = (await self.db.execute(stmt)).scalars().all()
        return [
            KBChunkResult(
                id=str(r.id),
                file_name=r.file_name,
                page_number=r.page_number,
                section_name=r.section_name,
                chunk_type=r.chunk_type,
                chunk_text=r.chunk_text,
                keywords=r.keywords or [],
                score=1.0,
            )
            for r in rows
        ]
