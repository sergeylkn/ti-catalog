"""
Reranker — Stage E of the pipeline.
Final ranking of candidates after compatibility filtering.
Priority: exact confidence > score > DN ascending.
"""

from app.schemas.search import ParsedQuery, SearchResult, ConfidenceLevel


CONFIDENCE_ORDER = {
    ConfidenceLevel.EXACT:   3,
    ConfidenceLevel.PARTIAL: 2,
    ConfidenceLevel.ANALOG:  1,
}


class Reranker:
    def rank(
        self,
        parsed: ParsedQuery,
        results: list[SearchResult],
    ) -> list[SearchResult]:
        """
        Rerank results by:
        1. Confidence level (exact > partial > analog)
        2. Relevance score (higher is better)
        3. DN proximity to requested (smaller diff = better)
        4. Completeness of attributes (more data = better)
        """
        if not results:
            return []

        def sort_key(r: SearchResult):
            conf_score = CONFIDENCE_ORDER.get(r.confidence_level, 0)

            # DN proximity bonus
            dn_diff = 9999.0
            if parsed.inner_diameter_mm and r.inner_diameter_mm:
                dn_diff = abs(r.inner_diameter_mm - parsed.inner_diameter_mm)

            # Attribute completeness bonus (0..5)
            completeness = sum([
                r.pressure_max_bar is not None,
                r.temp_max_c       is not None,
                r.inner_diameter_mm is not None,
                bool(r.material_normalized),
                r.source_page      is not None,
            ])

            # Pressure margin bonus (higher safety margin = better)
            pressure_margin = 0.0
            if parsed.min_pressure_bar and r.pressure_max_bar:
                pressure_margin = r.pressure_max_bar - parsed.min_pressure_bar

            return (
                -conf_score,          # highest confidence first
                -r.relevance_score,   # highest score first
                dn_diff,              # smallest DN diff first
                -completeness,        # most complete first
                -pressure_margin,     # most pressure margin first
            )

        return sorted(results, key=sort_key)
