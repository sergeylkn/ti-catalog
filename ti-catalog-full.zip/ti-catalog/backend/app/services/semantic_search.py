"""
Semantic Search Service — Stage C of the pipeline.
Used ONLY when structured search returns < 3 results.
Uses pgvector cosine similarity on product embeddings.
"""

import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
import anthropic

from app.core.config import settings
from app.db.models import Product, ProductAttribute
from app.schemas.search import ParsedQuery, SearchResult, ConfidenceLevel

logger = logging.getLogger(__name__)
ai = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)


class SemanticSearchService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def recall(
        self,
        query: str,
        parsed: ParsedQuery,
        limit: int = 10,
    ) -> list[SearchResult]:
        """
        Stage C: semantic vector recall.
        Embeds the query and finds similar products via cosine similarity.
        Results are always marked as ANALOG (not exact).
        """
        try:
            embedding = await self._embed(query)
        except Exception as e:
            logger.warning(f"Embedding failed: {e}")
            return []

        # pgvector cosine similarity search
        stmt = text("""
            SELECT
                p.id, p.article, p.sku, p.name, p.product_type, p.brand, p.series,
                p.source_file, p.source_page,
                a.inner_diameter_mm, a.outer_diameter_mm,
                a.pressure_max_bar, a.temp_min_c, a.temp_max_c,
                a.material_normalized, a.food_approved, a.vacuum_rated,
                a.thread_type, a.connection_type,
                1 - (p.embedding <=> :embedding::vector) AS similarity
            FROM products p
            LEFT JOIN product_attributes a ON a.product_id = p.id
            WHERE p.is_active = TRUE
              AND p.embedding IS NOT NULL
              AND 1 - (p.embedding <=> :embedding::vector) > :threshold
            ORDER BY p.embedding <=> :embedding::vector
            LIMIT :limit
        """)

        result = await self.db.execute(stmt, {
            "embedding": str(embedding),
            "threshold": settings.SEMANTIC_RECALL_THRESHOLD,
            "limit": limit,
        })
        rows = result.fetchall()

        results = []
        for row in rows:
            results.append(SearchResult(
                product_id=row.id,
                article=row.article or row.sku,
                name=row.name,
                product_type=row.product_type,
                brand=row.brand,
                series=row.series,
                inner_diameter_mm=row.inner_diameter_mm,
                outer_diameter_mm=row.outer_diameter_mm,
                pressure_max_bar=row.pressure_max_bar,
                temp_min_c=row.temp_min_c,
                temp_max_c=row.temp_max_c,
                material_normalized=row.material_normalized or [],
                food_approved=bool(row.food_approved),
                vacuum_rated=bool(row.vacuum_rated),
                thread_type=row.thread_type,
                connection_type=row.connection_type,
                source_file=row.source_file,
                source_page=row.source_page,
                confidence_level=ConfidenceLevel.ANALOG,
                relevance_score=float(row.similarity),
                why_fits=f"Семантична схожість {row.similarity:.0%}",
            ))

        logger.info(f"Semantic recall: {len(results)} results above threshold {settings.SEMANTIC_RECALL_THRESHOLD}")
        return results

    async def _embed(self, text: str) -> list[float]:
        """
        Generate embedding for a text string.
        Uses Anthropic's embedding API (or swap for OpenAI).
        """
        # NOTE: Anthropic doesn't have a public embedding API yet.
        # Use OpenAI text-embedding-3-small (1536 dims) or a local model.
        # This is a placeholder — swap for your embedding provider:
        try:
            import openai
            client = openai.OpenAI()
            resp = client.embeddings.create(
                model="text-embedding-3-small",
                input=text[:8000],
            )
            return resp.data[0].embedding
        except ImportError:
            # Fallback: return zeros (semantic search disabled)
            logger.warning("openai not installed — semantic search disabled")
            return [0.0] * 1536
