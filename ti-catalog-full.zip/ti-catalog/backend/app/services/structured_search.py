"""
Structured Search Service — Stage B of the pipeline
Pure SQL-based search with strict parameter filters.
No LLM involved — this is the ground truth layer.
"""

from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func

from app.db.models import Product, ProductAttribute
from app.schemas.search import ParsedQuery, SearchResult, ConfidenceLevel
from app.core.config import settings


class StructuredSearchService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def search(self, parsed: ParsedQuery) -> list[SearchResult]:
        """
        Stage B: strict structured search.
        Filters products using ONLY explicitly extracted parameters.
        Returns products with confidence level (exact/partial/analog).
        """
        conditions = []

        # ── Product type filter ─────────────────────────────────────────
        if parsed.product_type:
            type_map = {
                "hose":        ["Промислові шланги", "hose", "рукав"],
                "fitting":     ["Промислова арматура", "Прецизійна арматура", "fitting"],
                "valve":       ["клапан", "кран", "valve"],
                "hydraulics":  ["Силова гідравліка", "hydraulic"],
                "pneumatics":  ["Промислова пневматика", "pneumatic"],
                "compensator": ["Компенсатор", "compensator"],
                "gauge":       ["Вимірювальні системи", "gauge"],
                "accessory":   ["Пристрої та аксесуари", "accessory"],
            }
            type_terms = type_map.get(parsed.product_type, [])
            if type_terms:
                type_conds = or_(*[
                    Product.product_type.ilike(f"%{t}%")
                    for t in type_terms
                ])
                conditions.append(type_conds)

        # ── Material filter ─────────────────────────────────────────────
        if parsed.material:
            conditions.append(
                ProductAttribute.material_normalized.any(
                    parsed.material.upper()
                )
            )

        # ── Pressure filter — CRITICAL: only show products with enough pressure ─
        if parsed.min_pressure_bar is not None:
            conditions.append(
                or_(
                    ProductAttribute.pressure_max_bar >= parsed.min_pressure_bar,
                    ProductAttribute.pressure_max_bar.is_(None),  # unknown → include but flag
                )
            )

        # ── Temperature filter ──────────────────────────────────────────
        if parsed.temp_max_c is not None:
            conditions.append(
                or_(
                    ProductAttribute.temp_max_c >= parsed.temp_max_c,
                    ProductAttribute.temp_max_c.is_(None),
                )
            )
        if parsed.temp_min_c is not None:
            conditions.append(
                or_(
                    ProductAttribute.temp_min_c <= parsed.temp_min_c,
                    ProductAttribute.temp_min_c.is_(None),
                )
            )

        # ── Diameter filter ─────────────────────────────────────────────
        dn_exact = None
        if parsed.inner_diameter_mm is not None:
            dn = parsed.inner_diameter_mm
            dn_exact = dn
            # Exact first (within 0.5mm tolerance for manufacturing)
            conditions.append(
                or_(
                    and_(
                        ProductAttribute.inner_diameter_mm >= dn - 0.5,
                        ProductAttribute.inner_diameter_mm <= dn + 0.5,
                    ),
                    # Also include ±6mm for partial matches (handled in scoring)
                    and_(
                        ProductAttribute.inner_diameter_mm >= dn - 6,
                        ProductAttribute.inner_diameter_mm <= dn + 6,
                    ),
                    ProductAttribute.inner_diameter_mm.is_(None),
                )
            )

        # ── Thread type filter ──────────────────────────────────────────
        if parsed.thread_type:
            conditions.append(
                or_(
                    ProductAttribute.thread_type.ilike(f"%{parsed.thread_type}%"),
                    ProductAttribute.thread_type.is_(None),
                )
            )

        # ── Medium filter ───────────────────────────────────────────────
        if parsed.medium:
            conditions.append(
                or_(
                    ProductAttribute.medium_normalized.any(parsed.medium.lower()),
                    ProductAttribute.medium.ilike(f"%{parsed.medium}%"),
                    ProductAttribute.medium.is_(None),
                )
            )

        # ── Special flags ───────────────────────────────────────────────
        if parsed.food_approved is True:
            conditions.append(ProductAttribute.food_approved == True)
        if parsed.vacuum_rated is True:
            conditions.append(ProductAttribute.vacuum_rated == True)
        if parsed.atex_rated is True:
            conditions.append(ProductAttribute.atex_rated == True)

        # ── Execute query ───────────────────────────────────────────────
        stmt = (
            select(Product, ProductAttribute)
            .join(ProductAttribute, ProductAttribute.product_id == Product.id, isouter=True)
            .where(Product.is_active == True)
            .where(and_(*conditions) if conditions else True)
            .limit(settings.MAX_STRUCTURED_RESULTS * 3)  # over-fetch for scoring
        )

        result = await self.db.execute(stmt)
        rows = result.fetchall()

        # ── Score and classify each result ─────────────────────────────
        scored = []
        for product, attrs in rows:
            score, level, why = self._score(parsed, product, attrs, dn_exact)
            scored.append(SearchResult(
                product_id=product.id,
                article=product.article or product.sku,
                name=product.name,
                product_type=product.product_type,
                brand=product.brand,
                series=product.series,
                inner_diameter_mm=attrs.inner_diameter_mm if attrs else None,
                outer_diameter_mm=attrs.outer_diameter_mm if attrs else None,
                pressure_max_bar=attrs.pressure_max_bar if attrs else None,
                temp_min_c=attrs.temp_min_c if attrs else None,
                temp_max_c=attrs.temp_max_c if attrs else None,
                material_normalized=attrs.material_normalized if attrs else [],
                food_approved=attrs.food_approved if attrs else False,
                vacuum_rated=attrs.vacuum_rated if attrs else False,
                thread_type=attrs.thread_type if attrs else None,
                connection_type=attrs.connection_type if attrs else None,
                source_file=product.source_file,
                source_page=product.source_page,
                confidence_level=level,
                relevance_score=score,
                why_fits=why,
            ))

        # Sort by score descending, then DN ascending for same score
        scored.sort(key=lambda x: (-x.relevance_score, x.inner_diameter_mm or 9999))
        return scored

    def _score(
        self,
        parsed: ParsedQuery,
        product,
        attrs,
        dn_exact: Optional[float],
    ) -> tuple[float, ConfidenceLevel, str]:
        """
        Score a product against parsed parameters.
        Returns (score, confidence_level, why_fits explanation).
        """
        score = 0.0
        exact_matches = 0
        total_params = 0
        why = []
        mismatches = []

        if attrs is None:
            return 5.0, ConfidenceLevel.ANALOG, "Параметри відсутні в базі"

        # DN scoring
        if dn_exact is not None:
            total_params += 1
            dn = attrs.inner_diameter_mm
            if dn is not None:
                diff = abs(dn - dn_exact)
                if diff <= 0.5:
                    score += 50; exact_matches += 1
                    why.append(f"DN{int(dn_exact)} точно")
                elif diff <= 4:
                    score += 20
                    why.append(f"DN{int(dn)} ≈ DN{int(dn_exact)}")
                elif diff <= 12:
                    score += 5
                    mismatches.append(f"DN{int(dn)}≠DN{int(dn_exact)}")
                else:
                    score -= 10
                    mismatches.append(f"DN{int(dn)}≠DN{int(dn_exact)}")
            else:
                score += 3  # unknown, include tentatively

        # Pressure scoring
        if parsed.min_pressure_bar is not None:
            total_params += 1
            p = attrs.pressure_max_bar
            if p is not None:
                if p >= parsed.min_pressure_bar * 1.5:
                    score += 30; exact_matches += 1
                    why.append(f"P={p}бар >> {parsed.min_pressure_bar}бар")
                elif p >= parsed.min_pressure_bar:
                    score += 25; exact_matches += 1
                    why.append(f"P={p}бар ≥ {parsed.min_pressure_bar}бар")
                else:
                    score -= 20  # CRITICAL — insufficient pressure
                    mismatches.append(f"P={p}бар < {parsed.min_pressure_bar}бар НЕДОСТАТНЬО")
            else:
                score += 5

        # Material scoring
        if parsed.material:
            total_params += 1
            mats = [m.upper() for m in (attrs.material_normalized or [])]
            if parsed.material.upper() in mats:
                score += 40; exact_matches += 1
                why.append(f"{parsed.material}✓")
            else:
                mismatches.append(f"матеріал≠{parsed.material}")

        # Temperature scoring
        if parsed.temp_max_c is not None:
            total_params += 1
            t = attrs.temp_max_c
            if t is not None and t >= parsed.temp_max_c:
                score += 20; exact_matches += 1
                why.append(f"T до {t}°C")

        # Food scoring
        if parsed.food_approved is True:
            total_params += 1
            if attrs.food_approved:
                score += 30; exact_matches += 1
                why.append("FDA✓")
            else:
                mismatches.append("не харч.")

        # Vacuum scoring
        if parsed.vacuum_rated is True:
            total_params += 1
            if attrs.vacuum_rated:
                score += 25; exact_matches += 1
                why.append("вакуум✓")

        # Confidence level
        ratio = exact_matches / max(total_params, 1)
        if ratio >= 0.9 and not mismatches:
            level = ConfidenceLevel.EXACT
        elif ratio >= 0.5:
            level = ConfidenceLevel.PARTIAL
        else:
            level = ConfidenceLevel.ANALOG

        why_str = ", ".join(why)
        if mismatches:
            why_str += f" ⚠{', '.join(mismatches)}"

        return score, level, why_str or "—"
