-- =============================================================================
-- TUBES INTERNATIONAL — INTERACTIVE CATALOG
-- PostgreSQL + pgvector schema
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- for fuzzy text search

-- =============================================================================
-- CATEGORIES
-- =============================================================================
CREATE TABLE categories (
    id          SERIAL PRIMARY KEY,
    parent_id   INTEGER REFERENCES categories(id),
    name        VARCHAR(200) NOT NULL,
    slug        VARCHAR(200) UNIQUE NOT NULL,
    description TEXT,
    sort_order  INTEGER DEFAULT 0,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_categories_slug   ON categories(slug);

-- =============================================================================
-- PRODUCTS
-- =============================================================================
CREATE TABLE products (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku                 VARCHAR(100),
    article             VARCHAR(100),
    name                VARCHAR(500) NOT NULL,
    category_id         INTEGER REFERENCES categories(id),
    subcategory_id      INTEGER REFERENCES categories(id),
    product_type        VARCHAR(100),
    brand               VARCHAR(100),
    series              VARCHAR(100),
    short_description   TEXT,
    full_description    TEXT,

    -- Source
    source_file         VARCHAR(300),
    source_page         INTEGER,
    source_section      VARCHAR(200),
    raw_text_fragment   TEXT,

    -- Status
    verified            BOOLEAN DEFAULT FALSE,
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),

    -- Vector embedding for semantic search
    embedding           vector(1536)
);

CREATE INDEX idx_products_sku      ON products(sku);
CREATE INDEX idx_products_article  ON products(article);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_type     ON products(product_type);
CREATE INDEX idx_products_series   ON products(series);
-- Full-text search index
CREATE INDEX idx_products_fts ON products USING GIN(
    to_tsvector('russian', coalesce(name,'') || ' ' || coalesce(short_description,'') || ' ' || coalesce(article,''))
);
-- Vector similarity index
CREATE INDEX idx_products_embedding ON products USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 100);

-- =============================================================================
-- PRODUCT ATTRIBUTES (normalized parameters)
-- =============================================================================
CREATE TABLE product_attributes (
    id                      SERIAL PRIMARY KEY,
    product_id              UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,

    -- Pressures (bar)
    pressure_max_bar        NUMERIC(10,2),
    pressure_min_bar        NUMERIC(10,2),
    pressure_raw            VARCHAR(100),    -- original text "16 bar / 232 PSI"

    -- Temperatures (°C)
    temp_min_c              NUMERIC(6,1),
    temp_max_c              NUMERIC(6,1),
    temp_raw                VARCHAR(100),

    -- Diameters (mm)
    inner_diameter_mm       NUMERIC(8,2),
    outer_diameter_mm       NUMERIC(8,2),
    diameter_raw            VARCHAR(100),
    diameter_inch           VARCHAR(20),     -- "1/2\"", "3/4\"" etc.

    -- Thread / Connection
    thread_type             VARCHAR(50),     -- BSP, BSPT, NPT, metric, JIC, DIN, GOST
    thread_size_raw         VARCHAR(100),
    connection_type         VARCHAR(100),    -- CAMLOCK, Storz, TW, Guillemin, flanged
    standard                VARCHAR(100),    -- DIN EN 853, EN ISO 6945, etc.

    -- Medium / Application
    medium                  VARCHAR(200),    -- air, water, oil, steam, food, acids
    medium_normalized       VARCHAR(50)[]  , -- normalized array: {air, water, oil}

    -- Materials
    material_inner          VARCHAR(200),
    material_outer          VARCHAR(200),
    material_fittings       VARCHAR(200),
    material_normalized     VARCHAR(50)[],   -- {EPDM, NBR, PTFE}

    -- Physical
    length_mm               NUMERIC(10,2),
    length_raw              VARCHAR(100),
    weight_kg               NUMERIC(8,3),
    weight_raw              VARCHAR(100),

    -- Special flags
    food_approved           BOOLEAN DEFAULT FALSE,
    vacuum_rated            BOOLEAN DEFAULT FALSE,
    atex_rated              BOOLEAN DEFAULT FALSE,
    ce_certified            BOOLEAN DEFAULT FALSE,

    -- Extra attributes as JSONB
    extra                   JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_attrs_product  ON product_attributes(product_id);
CREATE INDEX idx_attrs_pressure ON product_attributes(pressure_max_bar);
CREATE INDEX idx_attrs_temp     ON product_attributes(temp_min_c, temp_max_c);
CREATE INDEX idx_attrs_dn       ON product_attributes(inner_diameter_mm);
CREATE INDEX idx_attrs_thread   ON product_attributes(thread_type);
CREATE INDEX idx_attrs_food     ON product_attributes(food_approved) WHERE food_approved = TRUE;
CREATE INDEX idx_attrs_vacuum   ON product_attributes(vacuum_rated)  WHERE vacuum_rated  = TRUE;
CREATE INDEX idx_attrs_mat      ON product_attributes USING GIN(material_normalized);
CREATE INDEX idx_attrs_medium   ON product_attributes USING GIN(medium_normalized);

-- =============================================================================
-- COMPATIBILITY RULES
-- =============================================================================
CREATE TABLE compatibility_rules (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(200) NOT NULL,
    description     TEXT,
    rule_type       VARCHAR(50) NOT NULL,  -- 'exclude', 'warn', 'suggest'
    priority        INTEGER DEFAULT 50,

    -- Condition: JSON matching logic
    condition       JSONB NOT NULL,
    -- Action: what to do when condition matches
    action          JSONB NOT NULL,

    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Example rules:
-- {"category": "hose", "medium": "pneumatics"} -> EXCLUDE {"category": "hydraulics"}
-- {"pressure_requested": {"gt": "pressure_max"}} -> EXCLUDE

-- =============================================================================
-- KNOWLEDGE BASE DOCUMENTS
-- =============================================================================
CREATE TABLE kb_documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_name       VARCHAR(300) NOT NULL UNIQUE,
    title           VARCHAR(500),
    section         VARCHAR(200),
    category_name   VARCHAR(200),
    page_count      INTEGER,
    file_size_bytes BIGINT,
    extracted_text  TEXT,
    status          VARCHAR(50) DEFAULT 'pending',  -- pending, processing, done, error
    error_msg       TEXT,
    indexed_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_docs_filename ON kb_documents(file_name);
CREATE INDEX idx_docs_status   ON kb_documents(status);

-- =============================================================================
-- KNOWLEDGE BASE CHUNKS (the actual searchable units)
-- =============================================================================
CREATE TABLE kb_chunks (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id         UUID NOT NULL REFERENCES kb_documents(id) ON DELETE CASCADE,
    file_name           VARCHAR(300) NOT NULL,
    page_number         INTEGER,
    section_name        VARCHAR(300),
    category_name       VARCHAR(200),
    chunk_index         INTEGER,

    chunk_text          TEXT NOT NULL,
    chunk_summary       TEXT,
    keywords            TEXT[],
    chunk_type          VARCHAR(50),  -- 'table', 'description', 'specs', 'note', 'header'

    -- Metadata
    char_count          INTEGER,
    token_estimate      INTEGER,

    -- Vector embedding
    embedding           vector(1536),

    -- Links to products
    related_product_ids UUID[],

    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_chunks_document   ON kb_chunks(document_id);
CREATE INDEX idx_chunks_file       ON kb_chunks(file_name);
CREATE INDEX idx_chunks_page       ON kb_chunks(page_number);
CREATE INDEX idx_chunks_type       ON kb_chunks(chunk_type);
CREATE INDEX idx_chunks_products   ON kb_chunks USING GIN(related_product_ids);
CREATE INDEX idx_chunks_keywords   ON kb_chunks USING GIN(keywords);

-- Full-text search on chunks
CREATE INDEX idx_chunks_fts ON kb_chunks USING GIN(
    to_tsvector('russian', coalesce(chunk_text,'') || ' ' || coalesce(chunk_summary,''))
);

-- Vector similarity index
CREATE INDEX idx_chunks_embedding ON kb_chunks USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 200);

-- =============================================================================
-- IMPORT LOG
-- =============================================================================
CREATE TABLE import_log (
    id              SERIAL PRIMARY KEY,
    file_name       VARCHAR(300),
    status          VARCHAR(50),  -- started, completed, failed
    products_found  INTEGER DEFAULT 0,
    products_saved  INTEGER DEFAULT 0,
    chunks_created  INTEGER DEFAULT 0,
    errors          JSONB DEFAULT '[]'::jsonb,
    started_at      TIMESTAMPTZ DEFAULT NOW(),
    completed_at    TIMESTAMPTZ
);

-- =============================================================================
-- SEARCH LOG (analytics)
-- =============================================================================
CREATE TABLE search_log (
    id              SERIAL PRIMARY KEY,
    session_id      VARCHAR(100),
    query_text      TEXT,
    parsed_params   JSONB,
    mode            VARCHAR(20),  -- exact, analog, kb, navigation
    results_count   INTEGER,
    confidence      NUMERIC(4,3),
    response_ms     INTEGER,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_search_log_session ON search_log(session_id);
CREATE INDEX idx_search_log_created ON search_log(created_at);

-- =============================================================================
-- USEFUL VIEWS
-- =============================================================================
CREATE VIEW v_products_full AS
SELECT
    p.id, p.sku, p.article, p.name,
    c.name  AS category,
    sc.name AS subcategory,
    p.product_type, p.brand, p.series,
    p.short_description,
    p.source_file, p.source_page,
    p.verified,
    a.pressure_max_bar, a.pressure_min_bar,
    a.temp_min_c, a.temp_max_c,
    a.inner_diameter_mm, a.outer_diameter_mm,
    a.thread_type, a.connection_type, a.standard,
    a.material_normalized, a.medium_normalized,
    a.food_approved, a.vacuum_rated, a.atex_rated, a.ce_certified,
    a.extra
FROM products p
LEFT JOIN product_attributes a  ON a.product_id = p.id
LEFT JOIN categories c          ON c.id = p.category_id
LEFT JOIN categories sc         ON sc.id = p.subcategory_id
WHERE p.is_active = TRUE;
