"""
Unit tests for core logic.
Run: pytest backend/tests/ -v
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from scripts.pdf_import.normalizer import (
    normalize_pressure, normalize_temperature, normalize_diameter,
    normalize_thread, normalize_materials, normalize_medium,
    is_food_approved, is_vacuum_rated,
)


# ── Pressure ─────────────────────────────────────────────────────────────────

class TestNormalizePressure:
    def test_bar(self):
        assert normalize_pressure("16 bar") == 16.0

    def test_bar_ukrainian(self):
        assert normalize_pressure("16 бар") == 16.0

    def test_psi(self):
        result = normalize_pressure("232 PSI")
        assert result is not None
        assert abs(result - 16.0) < 0.1

    def test_mpa(self):
        result = normalize_pressure("1.6 MPa")
        assert result == 16.0

    def test_combined(self):
        assert normalize_pressure("16 bar / 232 PSI") == 16.0

    def test_none(self):
        assert normalize_pressure("") is None
        assert normalize_pressure(None) is None


# ── Temperature ───────────────────────────────────────────────────────────────

class TestNormalizeTemperature:
    def test_range(self):
        mn, mx = normalize_temperature("-20 до +90°C")
        assert mn == -20.0
        assert mx == 90.0

    def test_range_english(self):
        mn, mx = normalize_temperature("-40 to +120°C")
        assert mn == -40.0
        assert mx == 120.0

    def test_max_only(self):
        mn, mx = normalize_temperature("max 150°C")
        assert mn is None
        assert mx == 150.0

    def test_dots_range(self):
        mn, mx = normalize_temperature("-20...+90°C")
        assert mn == -20.0
        assert mx == 90.0

    def test_empty(self):
        mn, mx = normalize_temperature("")
        assert mn is None and mx is None


# ── Diameter ──────────────────────────────────────────────────────────────────

class TestNormalizeDiameter:
    def test_dn(self):
        mm, inch = normalize_diameter("DN25")
        assert mm == 25.0

    def test_dn_space(self):
        mm, _ = normalize_diameter("DN 32")
        assert mm == 32.0

    def test_mm(self):
        mm, _ = normalize_diameter("25 mm")
        assert mm == 25.0

    def test_inch_fraction(self):
        mm, inch = normalize_diameter('1/2"')
        assert inch == "1/2"
        assert abs(mm - 12.7) < 0.1

    def test_inch_whole(self):
        mm, inch = normalize_diameter("1 inch")
        assert abs(mm - 25.4) < 0.1

    def test_combined(self):
        mm, _ = normalize_diameter('DN25 / 1"')
        assert mm == 25.0


# ── Thread ────────────────────────────────────────────────────────────────────

class TestNormalizeThread:
    def test_bsp(self):
        assert normalize_thread("1/2 BSP") == "BSP"

    def test_bspt(self):
        assert normalize_thread("BSPT 3/4") == "BSPT"

    def test_npt(self):
        assert normalize_thread("1/4 NPT") == "NPT"

    def test_metric(self):
        assert normalize_thread("M12x1.5") == "metric"

    def test_g_notation(self):
        assert normalize_thread("G 1/2") == "BSP"

    def test_none(self):
        assert normalize_thread("") is None


# ── Materials ─────────────────────────────────────────────────────────────────

class TestNormalizeMaterials:
    def test_epdm(self):
        assert "EPDM" in normalize_materials("EPDM rubber liner")

    def test_nbr(self):
        assert "NBR" in normalize_materials("NBR / Nitrile inner tube")

    def test_multiple(self):
        mats = normalize_materials("Inner: EPDM, Outer: SBR, Fittings: brass")
        assert "EPDM" in mats
        assert "SBR"  in mats
        assert "brass" in mats

    def test_stainless(self):
        assert "stainless" in normalize_materials("stainless steel fittings")

    def test_empty(self):
        assert normalize_materials("") == []


# ── Medium ────────────────────────────────────────────────────────────────────

class TestNormalizeMedium:
    def test_air(self):
        assert "air" in normalize_medium("for compressed air")

    def test_water(self):
        assert "water" in normalize_medium("water and steam")
        assert "steam" in normalize_medium("water and steam")

    def test_food(self):
        assert "food" in normalize_medium("харчові продукти, FDA")

    def test_fuel(self):
        assert "fuel" in normalize_medium("дизельне паливо")

    def test_empty(self):
        assert normalize_medium("") == []


# ── Special flags ─────────────────────────────────────────────────────────────

class TestSpecialFlags:
    def test_food_fda(self):
        assert is_food_approved("FDA approved hose") is True

    def test_food_nsf(self):
        assert is_food_approved("NSF certified") is True

    def test_food_ukrainian(self):
        assert is_food_approved("харчовий шланг") is True

    def test_not_food(self):
        assert is_food_approved("industrial hose for oil") is False

    def test_vacuum(self):
        assert is_vacuum_rated("vacuum rated -1 bar") is True
        assert is_vacuum_rated("вакуумостійкий") is True

    def test_not_vacuum(self):
        assert is_vacuum_rated("standard pressure hose") is False
