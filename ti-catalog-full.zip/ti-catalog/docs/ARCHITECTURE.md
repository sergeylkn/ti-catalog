# TUBES INTERNATIONAL — Interactive Catalog
## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER BROWSER                             │
│               Next.js Frontend (port 3000)                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Catalog  │  │ Filters  │  │  Card    │  │  AI Chat      │  │
│  │  Grid    │  │  Panel   │  │  Modal   │  │  Panel        │  │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └───────┬───────┘  │
└───────┼─────────────┼─────────────┼─────────────────┼──────────┘
        │             │             │                 │
        └─────────────┴─────────────┴─────────────────┘
                                │
                    REST API (HTTPS)
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                    FastAPI Backend (port 8000)                   │
│                                                                  │
│   /api/search        — structured DB search                      │
│   /api/ai/query      — 6-stage hybrid AI pipeline               │
│   /api/kb/search     — knowledge base text search                │
│   /api/products/:id  — product detail + related products         │
│   /api/filters       — available filter options                  │
│   /api/admin/*       — admin panel endpoints                     │
│                                                                  │
│ ┌────────────────────────────────────────────────────────────┐  │
│ │              AI QUERY PIPELINE (6 stages)                  │  │
│ │                                                            │  │
│ │  A. Parse ──→ B. Structured ──→ C. Semantic               │  │
│ │     (Claude)      (SQL)           (pgvector)               │  │
│ │      │               │                 │                   │  │
│ │      └───────────────┴─────────────────┘                   │  │
│ │                       │                                     │  │
│ │  D. Compat rules ──→ E. Rerank ──→ F. Explain              │  │
│ │     (hard rules)    (scoring)    (Claude)                   │  │
│ └────────────────────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────────────────┘
                           │
              ┌────────────┴────────────┐
              │                         │
┌─────────────▼──────────┐  ┌──────────▼──────────────────────────┐
│      PostgreSQL         │  │         Anthropic API               │
│   + pgvector            │  │    claude-opus-4-6 (explain)        │
│                         │  │    claude-haiku (parse, extract)    │
│  ┌─────────────────┐   │  └─────────────────────────────────────┘
│  │    products     │   │
│  │product_attributes│  │
│  │   categories    │   │
│  └─────────────────┘   │
│  ┌─────────────────┐   │
│  │  kb_documents   │   │
│  │   kb_chunks     │   │ ← Knowledge Base
│  │  (embeddings)   │   │
│  └─────────────────┘   │
│  ┌─────────────────┐   │
│  │compatibility_   │   │
│  │    rules        │   │
│  └─────────────────┘   │
└────────────────────────┘
```

## 6-Stage Hybrid Search Pipeline

```
User: "Потрібен шланг для повітря 10 бар DN12"
          │
          ▼
┌─────────────────────────────────────────────────────────┐
│  STAGE A: AI Parameter Extraction (Claude Haiku)        │
│  ─────────────────────────────────────────────────────  │
│  Input: natural language query                          │
│  Output: {                                              │
│    product_type: "hose",                                │
│    medium: "air",                                       │
│    min_pressure_bar: 10,                                │
│    inner_diameter_mm: 12,                               │
│    confidence: 0.92,                                    │
│    search_mode: "exact"                                 │
│  }                                                      │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  STAGE B: Structured DB Search (SQL — NO LLM!)         │
│  ─────────────────────────────────────────────────────  │
│  WHERE category LIKE 'hose%'                           │
│    AND pressure_max_bar >= 10                           │
│    AND inner_diameter_mm BETWEEN 8 AND 16               │
│    AND medium_normalized @> ARRAY['air']               │
│  → Returns 23 candidates                               │
└─────────────────┬───────────────────────────────────────┘
                  │ < 3 results? add semantic
                  ▼
┌─────────────────────────────────────────────────────────┐
│  STAGE C: Semantic Recall (pgvector cosine similarity) │
│  Only used when structured results insufficient        │
│  Adds 0-10 more candidates from embeddings             │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  STAGE D: Compatibility Rules (HARD RULES)             │
│  ─────────────────────────────────────────────────────  │
│  ✗ EXCLUDE hydraulics when pneumatics requested        │
│  ✗ EXCLUDE compensators when hose requested            │
│  ✗ EXCLUDE products with P_max < requested             │
│  ✗ EXCLUDE accessories for main product queries        │
│  ⚠ WARN on thread standard mismatch                   │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  STAGE E: Reranking                                    │
│  ─────────────────────────────────────────────────────  │
│  Score = DN_match + Pressure_match + Material_match     │
│  Confidence: 🟢 EXACT | 🟡 PARTIAL | 🔴 ANALOG        │
│  Sort: confidence desc, then score desc, then DN asc   │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  STAGE F: AI Explanation (Claude Opus)                 │
│  ─────────────────────────────────────────────────────  │
│  Context: top 25 products + KB chunks (if reference)  │
│  AI explains: why each product fits, what to note      │
│  AI CANNOT: invent articles, specs, or products       │
│  All product data comes from the DB, not from AI      │
└─────────────────────────────────────────────────────────┘
```

## Folder Structure

```
ti-catalog/
├── backend/
│   ├── app/
│   │   ├── main.py              ← FastAPI entry point
│   │   ├── api/
│   │   │   ├── search.py        ← GET /search, POST /ai/query
│   │   │   ├── products.py      ← GET /products/:id
│   │   │   ├── filters.py       ← GET /filters
│   │   │   ├── ai_query.py      ← AI chat endpoint
│   │   │   ├── kb.py            ← GET /kb/search
│   │   │   └── admin.py         ← Admin operations
│   │   ├── core/
│   │   │   └── config.py        ← Settings from .env
│   │   ├── db/
│   │   │   ├── session.py       ← Async DB session
│   │   │   └── models.py        ← SQLAlchemy ORM models
│   │   ├── schemas/
│   │   │   └── search.py        ← Pydantic schemas
│   │   └── services/
│   │       ├── ai_query.py      ← 6-stage pipeline orchestrator
│   │       ├── structured_search.py ← Stage B
│   │       ├── semantic_search.py   ← Stage C (pgvector)
│   │       ├── kb_search.py         ← KB text search
│   │       ├── compatibility.py     ← Stage D
│   │       └── reranker.py          ← Stage E
│   ├── schema.sql               ← DB schema
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   │   ├── page.tsx         ← Home / catalog
│   │   │   ├── layout.tsx
│   │   │   └── admin/page.tsx   ← Admin panel
│   │   ├── components/
│   │   │   ├── CatalogGrid.tsx
│   │   │   ├── FilterPanel.tsx
│   │   │   ├── ProductCard.tsx
│   │   │   ├── ProductModal.tsx
│   │   │   ├── AIChat.tsx       ← Main AI chat panel
│   │   │   └── ConfidenceBadge.tsx
│   │   ├── lib/
│   │   │   └── api.ts           ← API client
│   │   └── types/
│   │       └── catalog.ts       ← TypeScript types
│   └── package.json
└── scripts/
    ├── pdf_import/
    │   └── importer.py          ← PDF → PostgreSQL pipeline
    ├── kb_builder/
    │   └── build_kb.py          ← Text chunking + KB building
    └── embeddings/
        └── build_embeddings.py  ← Generate + store embeddings
```

## Key Design Decisions

1. **AI is optional in the search path** — structured search works without AI
2. **Hard rules cannot be overridden by AI** — compatibility enforced in Python
3. **All product data comes from DB** — AI only explains, never invents
4. **Confidence is explicit** — 🟢/🟡/🔴 shown on every result
5. **KB is separate** — reference queries go to knowledge base, not product DB
6. **Source always visible** — every result shows PDF file + page number

## Environment Variables (.env)

```env
DATABASE_URL=postgresql+asyncpg://postgres:password@localhost:5432/ti_catalog
ANTHROPIC_API_KEY=sk-ant-...
PDF_DIR=./pdf_catalog
ADMIN_SECRET=your-secret-key
CORS_ORIGINS=["http://localhost:3000"]
```
