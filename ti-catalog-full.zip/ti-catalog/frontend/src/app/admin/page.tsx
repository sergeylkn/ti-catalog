"use client";

import { useState, useEffect } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function adminFetch(path: string, method = "GET", body?: any) {
  const secret = localStorage.getItem("admin_secret") || "";
  const res = await fetch(`${API}/api/admin${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      "x-admin-secret": secret,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  return res.json();
}

type Tab = "import" | "products" | "documents" | "chunks";

export default function AdminPage() {
  const [tab,    setTab]    = useState<Tab>("import");
  const [secret, setSecret] = useState("");
  const [authed, setAuthed] = useState(false);
  const [msg,    setMsg]    = useState("");

  // Auth
  const login = () => {
    localStorage.setItem("admin_secret", secret);
    setAuthed(true);
  };

  if (!authed) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-8 w-96">
          <h1 className="text-xl font-bold mb-6">🔐 Admin Panel</h1>
          <input
            type="password"
            placeholder="Admin secret"
            value={secret}
            onChange={e => setSecret(e.target.value)}
            onKeyDown={e => e.key === "Enter" && login()}
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 mb-4
                       focus:outline-none focus:border-red-500"
          />
          <button
            onClick={login}
            className="w-full bg-red-600 hover:bg-red-700 py-2 rounded-lg font-semibold transition"
          >
            Увійти
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <a href="/" className="text-red-500 font-bold">← Tubes International</a>
          <span className="text-gray-600">|</span>
          <span className="font-semibold">Admin Panel</span>
        </div>
        {msg && (
          <div className="text-sm text-green-400 bg-green-500/10 px-4 py-1 rounded-full">
            ✓ {msg}
          </div>
        )}
      </header>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-gray-800">
          {(["import", "products", "documents", "chunks"] as Tab[]).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-5 py-2.5 text-sm font-semibold border-b-2 transition -mb-px
                ${tab === t
                  ? "border-red-500 text-white"
                  : "border-transparent text-gray-500 hover:text-gray-300"}`}
            >
              {{ import: "📥 Імпорт", products: "📦 Товари", documents: "📄 PDF", chunks: "🧩 Chunks" }[t]}
            </button>
          ))}
        </div>

        {tab === "import"    && <ImportTab setMsg={setMsg} />}
        {tab === "products"  && <ProductsTab />}
        {tab === "documents" && <DocumentsTab />}
        {tab === "chunks"    && <ChunksTab />}
      </div>
    </div>
  );
}

/* ── Import Tab ───────────────────────────────────────────────────── */
function ImportTab({ setMsg }: { setMsg: (m: string) => void }) {
  const [log, setLog]       = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    adminFetch("/import-log").then(setLog).catch(console.error);
  }, []);

  const startImport = async () => {
    setLoading(true);
    try {
      const r = await adminFetch("/import", "POST");
      setMsg(`Імпорт запущено — ${r.pdf_count} PDF файлів`);
      setTimeout(() => adminFetch("/import-log").then(setLog), 3000);
    } catch (e: any) {
      setMsg("Помилка: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const reindex = async (mode: string) => {
    await adminFetch(`/reindex?mode=${mode}`, "POST");
    setMsg(`Переіндексація запущена (${mode})`);
  };

  return (
    <div className="space-y-6">
      {/* Actions */}
      <div className="grid grid-cols-3 gap-4">
        <ActionCard
          title="Імпорт PDF"
          desc="Розпарсити PDF → товари + knowledge base"
          btn="▶ Запустити імпорт"
          loading={loading}
          onClick={startImport}
          color="red"
        />
        <ActionCard
          title="Embeddings"
          desc="Згенерувати вектори для товарів і chunks"
          btn="⚡ Embeddings (all)"
          onClick={() => reindex("all")}
          color="blue"
        />
        <ActionCard
          title="Тільки chunks"
          desc="Перебудувати Knowledge Base chunks"
          btn="🧩 Reindex KB"
          onClick={() => reindex("chunks")}
          color="green"
        />
      </div>

      {/* Import log */}
      <div>
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-3">
          Лог імпорту
        </h2>
        {log.length === 0 ? (
          <div className="text-gray-600 text-sm">Ще не було імпорту</div>
        ) : (
          <div className="space-y-2">
            {log.map((r, i) => (
              <div key={i} className="bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 flex items-center gap-4 text-sm">
                <span className={`w-2 h-2 rounded-full shrink-0 ${
                  r.status === "completed" ? "bg-green-500" :
                  r.status === "failed"    ? "bg-red-500"   : "bg-yellow-500"
                }`} />
                <span className="flex-1 font-mono text-xs text-gray-400">{r.file}</span>
                <span className="text-green-400">{r.products} товарів</span>
                <span className="text-blue-400">{r.chunks} chunks</span>
                <span className="text-gray-600 text-xs">{r.started?.slice(0, 16)}</span>
                {r.errors?.length > 0 && (
                  <span className="text-red-400 text-xs">{r.errors.length} помилок</span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Products Tab ─────────────────────────────────────────────────── */
function ProductsTab() {
  const [data,    setData]    = useState<any>(null);
  const [q,       setQ]       = useState("");
  const [page,    setPage]    = useState(1);
  const [unverif, setUnverif] = useState(false);

  const load = () =>
    adminFetch(`/products?q=${q}&verified=${unverif ? "false" : ""}&page=${page}`)
      .then(setData).catch(console.error);

  useEffect(() => { load(); }, [q, page, unverif]);

  const markVerified = async (id: string) => {
    await adminFetch(`/products/${id}`, "PATCH", { verified: true });
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-3">
        <input
          value={q}
          onChange={e => { setQ(e.target.value); setPage(1); }}
          placeholder="Пошук за назвою..."
          className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-red-500"
        />
        <label className="flex items-center gap-2 text-sm text-gray-400 cursor-pointer">
          <input type="checkbox" checked={unverif} onChange={e => setUnverif(e.target.checked)} className="accent-red-500" />
          Тільки неперевірені
        </label>
      </div>

      {data && (
        <>
          <div className="text-sm text-gray-500">{data.total.toLocaleString()} товарів</div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800 text-left">
                  {["Артикул", "Назва", "Тип", "PDF", "Стор.", "✓"].map(h => (
                    <th key={h} className="pb-2 pr-4 text-xs text-gray-500 font-semibold uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/50">
                {data.items.map((p: any) => (
                  <tr key={p.id} className="hover:bg-gray-800/30 transition">
                    <td className="py-2.5 pr-4 font-mono text-red-400 text-xs">{p.article || "—"}</td>
                    <td className="py-2.5 pr-4 max-w-xs truncate">{p.name}</td>
                    <td className="py-2.5 pr-4 text-gray-500 text-xs">{p.type}</td>
                    <td className="py-2.5 pr-4 text-gray-600 text-xs truncate max-w-[120px]">{p.source}</td>
                    <td className="py-2.5 pr-4 text-gray-600 text-xs">{p.page}</td>
                    <td className="py-2.5">
                      {p.verified ? (
                        <span className="text-green-400 text-xs">✓</span>
                      ) : (
                        <button
                          onClick={() => markVerified(p.id)}
                          className="text-xs text-gray-500 hover:text-green-400 transition"
                        >
                          Позначити
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex gap-2">
            {page > 1 && <button onClick={() => setPage(p => p - 1)} className="px-3 py-1 bg-gray-800 rounded text-sm">←</button>}
            <span className="px-3 py-1 text-sm text-gray-500">Стор. {page}</span>
            {data.items.length === 50 && <button onClick={() => setPage(p => p + 1)} className="px-3 py-1 bg-gray-800 rounded text-sm">→</button>}
          </div>
        </>
      )}
    </div>
  );
}

/* ── Documents Tab ────────────────────────────────────────────────── */
function DocumentsTab() {
  const [docs, setDocs] = useState<any[]>([]);

  useEffect(() => {
    adminFetch("/documents").then(setDocs).catch(console.error);
  }, []);

  const statusColor = (s: string) =>
    s === "done" ? "text-green-400" : s === "error" ? "text-red-400" : "text-yellow-400";

  return (
    <div>
      <div className="text-sm text-gray-500 mb-4">{docs.length} PDF документів</div>
      <div className="space-y-2">
        {docs.map(d => (
          <div key={d.id} className="bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 flex items-center gap-4 text-sm">
            <span className="flex-1 font-mono text-xs text-gray-300">{d.file_name}</span>
            <span className="text-gray-600">{d.pages} стор.</span>
            <span className={`text-xs font-semibold ${statusColor(d.status)}`}>{d.status}</span>
            <span className="text-gray-600 text-xs">{d.indexed_at?.slice(0, 16)}</span>
          </div>
        ))}
        {docs.length === 0 && (
          <div className="text-gray-600 text-sm text-center py-8">
            Немає імпортованих PDF. Запустіть імпорт на вкладці "Імпорт".
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Chunks Tab ───────────────────────────────────────────────────── */
function ChunksTab() {
  const [chunks,   setChunks]   = useState<any[]>([]);
  const [fileName, setFileName] = useState("");
  const [page,     setPage]     = useState(1);

  useEffect(() => {
    adminFetch(`/chunks?file_name=${fileName}&page=${page}`)
      .then(setChunks).catch(console.error);
  }, [fileName, page]);

  return (
    <div className="space-y-4">
      <input
        value={fileName}
        onChange={e => { setFileName(e.target.value); setPage(1); }}
        placeholder="Фільтр за ім'ям PDF файлу..."
        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-red-500"
      />
      <div className="space-y-3">
        {chunks.map(c => (
          <div key={c.id} className="bg-gray-900 border border-gray-800 rounded-lg p-4">
            <div className="flex items-center gap-3 mb-2 text-xs text-gray-500">
              <span className="font-mono">{c.file}</span>
              <span>стор. {c.page}</span>
              <span className="bg-gray-800 px-2 py-0.5 rounded">{c.type}</span>
              {c.products?.length > 0 && (
                <span className="text-blue-400">{c.products.length} товарів</span>
              )}
            </div>
            <p className="text-sm text-gray-300 leading-relaxed">{c.text}</p>
            {c.keywords?.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {c.keywords.map((k: string) => (
                  <span key={k} className="text-xs bg-gray-800 px-2 py-0.5 rounded-full text-gray-500">{k}</span>
                ))}
              </div>
            )}
          </div>
        ))}
        {chunks.length === 0 && (
          <div className="text-gray-600 text-sm text-center py-8">Немає chunks</div>
        )}
      </div>
      <div className="flex gap-2">
        {page > 1 && <button onClick={() => setPage(p => p - 1)} className="px-3 py-1 bg-gray-800 rounded text-sm">←</button>}
        <span className="px-3 py-1 text-sm text-gray-500">Стор. {page}</span>
        {chunks.length === 50 && <button onClick={() => setPage(p => p + 1)} className="px-3 py-1 bg-gray-800 rounded text-sm">→</button>}
      </div>
    </div>
  );
}

/* ── Helper ───────────────────────────────────────────────────────── */
function ActionCard({ title, desc, btn, onClick, loading, color }: {
  title: string; desc: string; btn: string;
  onClick: () => void; loading?: boolean; color: string;
}) {
  const colors: Record<string, string> = {
    red:   "bg-red-600 hover:bg-red-700",
    blue:  "bg-blue-600 hover:bg-blue-700",
    green: "bg-green-600 hover:bg-green-700",
  };
  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
      <div className="font-semibold mb-1">{title}</div>
      <div className="text-sm text-gray-500 mb-4">{desc}</div>
      <button
        onClick={onClick}
        disabled={loading}
        className={`w-full py-2 rounded-lg text-sm font-semibold transition disabled:opacity-50 ${colors[color]}`}
      >
        {loading ? "⏳ Запускається..." : btn}
      </button>
    </div>
  );
}
