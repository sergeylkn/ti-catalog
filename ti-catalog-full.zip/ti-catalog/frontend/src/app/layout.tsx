import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tubes International — Каталог",
  description: "Інтерактивний каталог промислових шлангів та арматури",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="uk">
      <body>{children}</body>
    </html>
  );
}
