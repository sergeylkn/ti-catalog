"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { searchProducts, getFilters, aiQuery } from "@/lib/api";
import type { SearchResult, FilterOptions, ChatMessage } from "@/types/catalog";
import FilterPanel from "@/components/FilterPanel";
import CatalogGrid from "@/components/CatalogGrid";
import AIChat from "@/components/AIChat";
import ProductModal from "@/components/ProductModal";

export default function HomePage() {
  // ── State ────────────────────────────────────────────────────────
  const [query,     setQuery]     = useState("");
  const [results,   setResults]   = useState<SearchResult[]>([]);
  const [total,     setTotal]     = useState(0);
  const [page,      setPage]      = useState(1);
  const [loading,   setLoading]   = useState(false);
  const [filters,   setFilters]   = useState<FilterOptions | null>(null);
  const [activeFilters, setActiveFilters] = useState<Record<string, any>>({});
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showChat,  setShowChat]  = useState(false);
  const [messages,  setMessages]  = useState<ChatMessage[]>([]);
  const [sessionId] = useState(() => Math.random().toString(36).slice(2));

  // ── Load filter options on mount ─────────────────────────────────
  useEffect(() => {
    getFilters().then(setFilters).catch(console.error);
  }, []);

  // ── Search ───────────────────────────────────────────────────────
  const doSearch = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const res = await searchProducts({
        q: query || "*",
        page: p,
        page_size: 24,
        ...activeFilters,
      });
      setResults(res.results);
      setTotal(res.total);
      setPage(p);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [query, activeFilters]);

  useEffect(() => { doSearch(1); }, [activeFilters]);

  // ── AI Chat ──────────────────────────────────────────────────────
  const sendMessage = async (text: string) => {
    const userMsg: ChatMessage = { role: "user", content: text, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);

    const history = messages.map(m => ({ role: m.role, content: m.content }));
    try {
      const resp = await aiQuery(text, history, sessionId);
      const aiMsg: ChatMessage = {
        role: "assistant",
        content: resp.html_response,
        html: resp.html_response,
        parsed: resp.parsed,
        results: resp.results,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMsg]);

      // If AI found products, show them in the catalog grid
      if (resp.results.length > 0) {
        setResults(resp.results);
        setTotal(resp.results.length);
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* ── Top bar ────────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 bg-gray-900/80 backdrop-blur border-b border-gray-800">
        <div className="max-w-screen-2xl mx-auto px-4 h-14 flex items-center gap-4">
          <span className="font-bold text-lg text-red-500 shrink-0">
            Tubes International
          </span>

          {/* Search bar */}
          <form
            onSubmit={e => { e.preventDefault(); doSearch(1); }}
            className="flex-1 flex gap-2"
          >
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Шланг EPDM DN25 16 бар... або артикул..."
              className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-sm
                         focus:outline-none focus:border-red-500 transition"
            />
            <button
              type="submit"
              className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg text-sm font-semibold transition"
            >
              Знайти
            </button>
          </form>

          {/* AI Chat toggle */}
          <button
            onClick={() => setShowChat(c => !c)}
            className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition
              ${showChat ? "bg-red-600 text-white" : "bg-gray-800 text-gray-300 hover:bg-gray-700"}`}
          >
            🤖 AI-помічник
          </button>
        </div>
      </header>

      <div className="max-w-screen-2xl mx-auto px-4 py-6 flex gap-6">
        {/* ── Filters sidebar ──────────────────────────────────── */}
        <aside className="w-64 shrink-0 hidden lg:block">
          {filters && (
            <FilterPanel
              filters={filters}
              active={activeFilters}
              onChange={f => { setActiveFilters(f); }}
            />
          )}
        </aside>

        {/* ── Main content ─────────────────────────────────────── */}
        <main className="flex-1 min-w-0">
          {/* Results header */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-gray-400">
              {loading ? "Пошук..." : `${total.toLocaleString()} позицій`}
            </span>
            <div className="flex gap-2 text-xs text-gray-500">
              <span>🟢 точне</span>
              <span>🟡 часткове</span>
              <span>🔴 аналог</span>
            </div>
          </div>

          {/* Catalog grid */}
          <CatalogGrid
            results={results}
            loading={loading}
            onProductClick={id => setSelectedId(id)}
            onAskAI={q => { setShowChat(true); sendMessage(q); }}
          />

          {/* Pagination */}
          {total > 24 && (
            <div className="flex justify-center gap-2 mt-8">
              {page > 1 && (
                <button
                  onClick={() => doSearch(page - 1)}
                  className="px-4 py-2 bg-gray-800 rounded-lg text-sm hover:bg-gray-700"
                >
                  ← Назад
                </button>
              )}
              <span className="px-4 py-2 text-sm text-gray-400">
                Стор. {page} / {Math.ceil(total / 24)}
              </span>
              {page * 24 < total && (
                <button
                  onClick={() => doSearch(page + 1)}
                  className="px-4 py-2 bg-gray-800 rounded-lg text-sm hover:bg-gray-700"
                >
                  Далі →
                </button>
              )}
            </div>
          )}
        </main>

        {/* ── AI Chat panel ─────────────────────────────────────── */}
        {showChat && (
          <aside className="w-96 shrink-0">
            <AIChat
              messages={messages}
              onSend={sendMessage}
              onClose={() => setShowChat(false)}
            />
          </aside>
        )}
      </div>

      {/* ── Product Modal ─────────────────────────────────────────── */}
      {selectedId && (
        <ProductModal
          productId={selectedId}
          onClose={() => setSelectedId(null)}
          onAskAI={q => { setShowChat(true); sendMessage(q); }}
        />
      )}
    </div>
  );
}
