"use client";

import { useState, useRef, useEffect } from "react";
import type { ChatMessage } from "@/types/catalog";

interface Props {
  messages: ChatMessage[];
  onSend: (text: string) => void;
  onClose: () => void;
}

const QUICK_QUERIES = [
  { icon: "⛽", text: "Шланг для бензину DN25 8 бар" },
  { icon: "🥛", text: "Харчовий шланг пара 150°C FDA" },
  { icon: "⚗️", text: "EPDM шланг кислоти DN32 6 бар" },
  { icon: "🔧", text: "Гідравліка 400 бар DN12" },
  { icon: "❓", text: "Чим відрізняється EPDM від NBR?" },
  { icon: "🔗", text: "Що таке CAMLOCK з'єднання?" },
];

const CHIPS = ["+DN", "+тиск", "+темп", "FDA", "вакуум", "PTFE"];

export default function AIChat({ messages, onSend, onClose }: Props) {
  const [input, setInput]     = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    setLoading(true);
    await onSend(text);
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] sticky top-20
                    bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-900/80">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-xs font-bold">
            TI
          </div>
          <div>
            <div className="text-sm font-semibold">AI-помічник</div>
            <div className="text-xs text-gray-500">claude-opus-4-6 · Tubes International</div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-gray-500 hover:text-gray-300 text-lg transition"
        >
          ✕
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <EmptyState onQuick={t => { setInput(t); }} />
        ) : (
          messages.map((m, i) => (
            <Message key={i} msg={m} />
          ))
        )}
        {loading && <TypingIndicator />}
        <div ref={bottomRef} />
      </div>

      {/* Input area */}
      <div className="border-t border-gray-800 p-3 space-y-2">
        {/* Chips */}
        <div className="flex flex-wrap gap-1">
          {CHIPS.map(c => (
            <button
              key={c}
              onClick={() => setInput(prev => prev + " " + c)}
              className="text-xs px-2 py-0.5 bg-gray-800 hover:bg-gray-700
                         border border-gray-700 rounded-full transition"
            >
              {c}
            </button>
          ))}
        </div>

        {/* Textarea + send */}
        <div className="flex gap-2">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            rows={2}
            placeholder="Опишіть задачу: шланг DN25 повітря 10 бар..."
            className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2
                       text-sm resize-none focus:outline-none focus:border-red-500 transition"
          />
          <button
            onClick={send}
            disabled={loading || !input.trim()}
            className="self-end px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-40
                       rounded-lg text-sm font-bold transition"
          >
            ➤
          </button>
        </div>

        {/* Confidence legend */}
        <div className="flex gap-4 text-xs text-gray-600">
          <span>🟢 точне</span>
          <span>🟡 часткове</span>
          <span>🔴 аналог</span>
          <span className="ml-auto">Enter — надіслати</span>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ onQuick }: { onQuick: (t: string) => void }) {
  return (
    <div className="flex flex-col items-center text-center py-6 gap-4">
      <div className="text-4xl">🤖</div>
      <div>
        <div className="font-bold mb-1">Технічний консультант</div>
        <div className="text-sm text-gray-400">
          Підбирає товари з бази за параметрами.<br />
          Не вигадує — тільки перевірені дані.
        </div>
      </div>

      <div className="w-full space-y-2">
        <div className="text-xs text-gray-500 text-left font-bold uppercase tracking-wider mb-1">
          Швидкі запити:
        </div>
        {QUICK_QUERIES.map(q => (
          <button
            key={q.text}
            onClick={() => onQuick(q.text)}
            className="w-full text-left text-sm px-3 py-2 bg-gray-800 hover:bg-gray-750
                       border border-gray-700 hover:border-gray-600 rounded-lg transition flex gap-2"
          >
            <span>{q.icon}</span>
            <span className="text-gray-300">{q.text}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function Message({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === "user";

  return (
    <div className={`flex gap-2 ${isUser ? "flex-row-reverse" : ""}`}>
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold shrink-0
                       ${isUser ? "bg-gray-700" : "bg-red-600"}`}>
        {isUser ? "👤" : "TI"}
      </div>
      <div className={`flex-1 max-w-[85%] ${isUser ? "text-right" : ""}`}>
        {/* Parsed params badge */}
        {!isUser && msg.parsed && (
          <ParsedParamsBadge parsed={msg.parsed} />
        )}

        {/* Message bubble */}
        <div
          className={`rounded-xl px-4 py-3 text-sm leading-relaxed
            ${isUser
              ? "bg-red-600/20 border border-red-600/30 ml-auto"
              : "bg-gray-800 border border-gray-700"}`}
        >
          {msg.html ? (
            <div
              className="ai-response"
              dangerouslySetInnerHTML={{ __html: msg.html }}
            />
          ) : (
            <p>{msg.content}</p>
          )}
        </div>

        <div className="text-xs text-gray-600 mt-1 px-1">
          {msg.timestamp.toLocaleTimeString("uk-UA", { hour: "2-digit", minute: "2-digit" })}
        </div>
      </div>
    </div>
  );
}

function ParsedParamsBadge({ parsed }: { parsed: any }) {
  const tags = [
    parsed.product_type && { label: `🎯 ${parsed.product_type}`, cls: "text-red-400 bg-red-500/10 border-red-500/20" },
    parsed.material     && { label: `🧪 ${parsed.material}`,     cls: "text-green-400 bg-green-500/10 border-green-500/20" },
    parsed.inner_diameter_mm && { label: `⌀ DN${parsed.inner_diameter_mm}`, cls: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
    parsed.min_pressure_bar  && { label: `🔵 ≥${parsed.min_pressure_bar} бар`, cls: "text-amber-400 bg-amber-500/10 border-amber-500/20" },
    parsed.medium       && { label: `💧 ${parsed.medium}`,       cls: "text-purple-400 bg-purple-500/10 border-purple-500/20" },
    parsed.food_approved && { label: "🥛 FDA",                   cls: "text-green-400 bg-green-500/10 border-green-500/20" },
  ].filter(Boolean) as { label: string; cls: string }[];

  if (!tags.length) return null;

  return (
    <div className="flex flex-wrap gap-1 mb-2">
      <span className="text-xs text-gray-600 self-center">Параметри:</span>
      {tags.map(t => (
        <span
          key={t.label}
          className={`text-xs px-2 py-0.5 rounded-full border font-medium ${t.cls}`}
        >
          {t.label}
        </span>
      ))}
    </div>
  );
}

function TypingIndicator() {
  return (
    <div className="flex gap-2">
      <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-xs font-bold">
        TI
      </div>
      <div className="bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 flex gap-1">
        {[0, 1, 2].map(i => (
          <span
            key={i}
            className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"
            style={{ animationDelay: `${i * 0.15}s` }}
          />
        ))}
      </div>
    </div>
  );
}
