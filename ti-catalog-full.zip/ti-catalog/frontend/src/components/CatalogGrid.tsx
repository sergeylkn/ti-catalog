"use client";

import type { SearchResult } from "@/types/catalog";

interface Props {
  results: SearchResult[];
  loading: boolean;
  onProductClick: (id: string) => void;
  onAskAI: (q: string) => void;
}

export default function CatalogGrid({ results, loading, onProductClick, onAskAI }: Props) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="bg-gray-900 rounded-xl h-52 animate-pulse" />
        ))}
      </div>
    );
  }

  if (!results.length) {
    return (
      <div className="text-center py-20">
        <div className="text-5xl mb-4">🔍</div>
        <h3 className="text-xl font-bold mb-2">Нічого не знайдено</h3>
        <p className="text-gray-400 mb-6">
          Спробуйте змінити параметри або запитайте AI-помічника
        </p>
        <button
          onClick={() => onAskAI("Допоможіть підібрати продукт")}
          className="bg-red-600 hover:bg-red-700 px-6 py-3 rounded-lg font-semibold transition"
        >
          🤖 Запитати AI
        </button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
      {results.map(r => (
        <ProductCard
          key={r.product_id}
          result={r}
          onClick={() => onProductClick(r.product_id)}
          onAskAI={onAskAI}
        />
      ))}
    </div>
  );
}

function ProductCard({ result: r, onClick, onAskAI }: {
  result: SearchResult;
  onClick: () => void;
  onAskAI: (q: string) => void;
}) {
  const dn   = r.inner_diameter_mm ? `DN${Math.round(r.inner_diameter_mm)}` : null;
  const pres = r.pressure_max_bar  ? `${r.pressure_max_bar} бар` : null;
  const temp = r.temp_max_c != null ? `до ${r.temp_max_c}°C` : null;
  const mat  = r.material_normalized.slice(0, 2).join(", ") || null;

  // Top border color by type
  const typeColor: Record<string, string> = {
    hose:        "border-t-red-500",
    hydraulics:  "border-t-blue-500",
    fitting:     "border-t-green-500",
    pneumatics:  "border-t-purple-500",
    valve:       "border-t-yellow-500",
  };
  const borderColor = typeColor[r.product_type || ""] || "border-t-gray-600";

  return (
    <div
      className={`bg-gray-900 border border-gray-800 border-t-2 ${borderColor}
                  rounded-xl p-4 flex flex-col gap-3 cursor-pointer
                  hover:-translate-y-1 hover:shadow-lg hover:shadow-black/40
                  transition-all duration-200`}
      onClick={onClick}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="text-xs text-gray-500 mb-1 truncate">
            {r.product_type} {r.series && `· ${r.series}`}
          </div>
          <div className="font-semibold text-sm leading-tight line-clamp-2">
            {r.name}
          </div>
        </div>
        <span className="text-lg shrink-0" title={confidenceLabel(r.confidence_level)}>
          {r.confidence_level}
        </span>
      </div>

      {/* Article */}
      {r.article && (
        <div className="bg-gray-800 rounded px-2 py-1 text-xs font-mono text-red-400 w-fit">
          {r.article}
        </div>
      )}

      {/* Parameters */}
      <div className="flex flex-wrap gap-2 text-xs">
        {dn   && <Tag label={dn}   color="blue" />}
        {pres && <Tag label={pres} color="amber" />}
        {temp && <Tag label={temp} color="purple" />}
        {mat  && <Tag label={mat}  color="green" />}
        {r.food_approved && <Tag label="FDA" color="green" />}
        {r.vacuum_rated  && <Tag label="Вакуум" color="blue" />}
      </div>

      {/* Why fits */}
      {r.why_fits && r.why_fits !== "—" && (
        <div className="text-xs text-gray-500 border-t border-gray-800 pt-2 line-clamp-1">
          {r.why_fits}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between mt-auto pt-1">
        {r.source_file && (
          <span className="text-xs text-gray-600">
            📄 {r.source_file.replace(".pdf", "")}
            {r.source_page ? ` стор.${r.source_page}` : ""}
          </span>
        )}
        <button
          className="text-xs text-red-500 hover:text-red-400 transition ml-auto"
          onClick={e => {
            e.stopPropagation();
            onAskAI(`Розкажи детальніше про ${r.article || r.name}`);
          }}
        >
          🤖 AI →
        </button>
      </div>

      {/* Warnings */}
      {r.warnings?.map((w, i) => (
        <div key={i} className="text-xs text-yellow-500 bg-yellow-500/10 rounded px-2 py-1">
          ⚠ {w}
        </div>
      ))}
    </div>
  );
}

function Tag({ label, color }: { label: string; color: string }) {
  const colors: Record<string, string> = {
    blue:   "bg-blue-500/10 text-blue-400 border-blue-500/20",
    amber:  "bg-amber-500/10 text-amber-400 border-amber-500/20",
    green:  "bg-green-500/10 text-green-400 border-green-500/20",
    purple: "bg-purple-500/10 text-purple-400 border-purple-500/20",
    red:    "bg-red-500/10 text-red-400 border-red-500/20",
  };
  return (
    <span className={`px-2 py-0.5 rounded border text-xs font-medium ${colors[color] || colors.blue}`}>
      {label}
    </span>
  );
}

function confidenceLabel(c: string) {
  if (c === "🟢") return "Точне співпадіння";
  if (c === "🟡") return "Часткове співпадіння";
  return "Аналог";
}
