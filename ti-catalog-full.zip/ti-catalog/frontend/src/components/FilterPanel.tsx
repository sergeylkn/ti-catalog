"use client";

import { useState } from "react";
import type { FilterOptions } from "@/types/catalog";

interface Props {
  filters: FilterOptions;
  active: Record<string, any>;
  onChange: (f: Record<string, any>) => void;
}

export default function FilterPanel({ filters, active, onChange }: Props) {
  const set = (key: string, val: any) => {
    const next = { ...active };
    if (val === "" || val === null || val === undefined) delete next[key];
    else next[key] = val;
    onChange(next);
  };

  const reset = () => onChange({});
  const hasActive = Object.keys(active).length > 0;

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 space-y-5 sticky top-20">
      <div className="flex items-center justify-between">
        <span className="font-semibold text-sm">Фільтри</span>
        {hasActive && (
          <button
            onClick={reset}
            className="text-xs text-red-500 hover:text-red-400 transition"
          >
            Скинути
          </button>
        )}
      </div>

      {/* Category */}
      <Section title="Категорія">
        <div className="space-y-1">
          {filters.product_types.slice(0, 8).map(t => (
            <label key={t} className="flex items-center gap-2 cursor-pointer group">
              <input
                type="radio"
                name="category"
                checked={active.category === t}
                onChange={() => set("category", active.category === t ? "" : t)}
                className="accent-red-500"
              />
              <span className="text-sm text-gray-300 group-hover:text-white transition capitalize">
                {t}
              </span>
            </label>
          ))}
        </div>
      </Section>

      {/* Material */}
      <Section title="Матеріал">
        <select
          value={active.material || ""}
          onChange={e => set("material", e.target.value)}
          className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2
                     text-sm focus:outline-none focus:border-red-500"
        >
          <option value="">Всі матеріали</option>
          {filters.materials.map(m => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>
      </Section>

      {/* DN */}
      <Section title={`DN (діаметр) мм`}>
        <div className="flex gap-2">
          <input
            type="number"
            placeholder="від"
            value={active.dn_min || ""}
            onChange={e => set("dn_min", e.target.value ? Number(e.target.value) : "")}
            className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-1.5 text-sm
                       focus:outline-none focus:border-red-500"
          />
          <input
            type="number"
            placeholder="до"
            value={active.dn_max || ""}
            onChange={e => set("dn_max", e.target.value ? Number(e.target.value) : "")}
            className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-1.5 text-sm
                       focus:outline-none focus:border-red-500"
          />
        </div>
      </Section>

      {/* Pressure */}
      <Section title="Тиск мін. (бар)">
        <input
          type="number"
          placeholder={`до ${filters.pressure_range.max} бар`}
          value={active.p_min || ""}
          onChange={e => set("p_min", e.target.value ? Number(e.target.value) : "")}
          className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-1.5 text-sm
                     focus:outline-none focus:border-red-500"
        />
      </Section>

      {/* Special flags */}
      <Section title="Спеціальні вимоги">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={!!active.food}
            onChange={e => set("food", e.target.checked || "")}
            className="accent-red-500 w-4 h-4"
          />
          <span className="text-sm text-gray-300">
            🥛 FDA / харчовий ({filters.special.food_approved})
          </span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer mt-2">
          <input
            type="checkbox"
            checked={!!active.vacuum}
            onChange={e => set("vacuum", e.target.checked || "")}
            className="accent-red-500 w-4 h-4"
          />
          <span className="text-sm text-gray-300">
            🌀 Вакуумстійкий ({filters.special.vacuum_rated})
          </span>
        </label>
      </Section>

      {/* Thread */}
      {filters.thread_types.length > 0 && (
        <Section title="Різьба">
          <select
            value={active.thread || ""}
            onChange={e => set("thread", e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2
                       text-sm focus:outline-none focus:border-red-500"
          >
            <option value="">Всі типи</option>
            {filters.thread_types.map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </Section>
      )}

      <div className="pt-2 border-t border-gray-800 text-xs text-gray-600 text-center">
        {filters.total_products.toLocaleString()} позицій в базі
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
        {title}
      </div>
      {children}
    </div>
  );
}
