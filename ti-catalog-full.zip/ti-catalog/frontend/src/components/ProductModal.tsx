"use client";

import { useEffect, useState } from "react";
import { getProduct } from "@/lib/api";

interface Props {
  productId: string;
  onClose: () => void;
  onAskAI: (q: string) => void;
}

export default function ProductModal({ productId, onClose, onAskAI }: Props) {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    getProduct(productId).then(setData).catch(console.error);
  }, [productId]);

  if (!data) {
    return (
      <Overlay onClose={onClose}>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full" />
        </div>
      </Overlay>
    );
  }

  const a = data.attributes || {};

  return (
    <Overlay onClose={onClose}>
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="text-xs text-gray-500 mb-1">{data.product_type} {data.series && `· ${data.series}`}</div>
          <h2 className="text-xl font-bold">{data.name}</h2>
          {data.short_description && (
            <p className="text-sm text-gray-400 mt-1">{data.short_description}</p>
          )}
        </div>
        <button onClick={onClose} className="text-gray-500 hover:text-white text-2xl ml-4">✕</button>
      </div>

      {/* Article */}
      {data.article && (
        <div className="mb-4">
          <span className="bg-gray-800 font-mono text-red-400 px-3 py-1 rounded text-sm">
            {data.article}
          </span>
          {data.verified && (
            <span className="ml-2 text-xs text-green-400 bg-green-500/10 px-2 py-1 rounded">
              ✓ Перевірено
            </span>
          )}
        </div>
      )}

      {/* Parameters table */}
      <div className="bg-gray-800 rounded-xl overflow-hidden mb-4">
        <table className="w-full text-sm">
          <tbody>
            {[
              ["Тиск макс.",     a.pressure_max_bar  ? `${a.pressure_max_bar} бар` : null, a.pressure_raw],
              ["Температура",    a.temp_min_c != null ? `${a.temp_min_c} … ${a.temp_max_c}°C` : null, a.temp_raw],
              ["DN (внутр.)",    a.inner_diameter_mm ? `${a.inner_diameter_mm} мм` : null, a.diameter_raw],
              ["DN (зовн.)",     a.outer_diameter_mm ? `${a.outer_diameter_mm} мм` : null],
              ["Матеріал",       a.material_normalized?.join(", ") || a.material_inner],
              ["Середовище",     a.medium_normalized?.join(", ") || a.medium],
              ["Різьба",         a.thread_type ? `${a.thread_type} ${a.thread_size_raw || ""}` : null],
              ["З'єднання",      a.connection_type],
              ["Стандарт",       a.standard],
              ["Вага",           a.weight_kg ? `${a.weight_kg} кг` : null, a.weight_raw],
            ]
              .filter(([, v]) => v)
              .map(([label, val, raw]) => (
                <tr key={String(label)} className="border-b border-gray-700/50 last:border-0">
                  <td className="px-4 py-2.5 text-gray-500 w-36 font-medium">{label}</td>
                  <td className="px-4 py-2.5 text-white">
                    {val}
                    {raw && raw !== val && (
                      <span className="text-gray-600 text-xs ml-2">({raw})</span>
                    )}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      {/* Special flags */}
      <div className="flex gap-2 flex-wrap mb-4">
        {a.food_approved && <Badge label="🥛 FDA" green />}
        {a.vacuum_rated  && <Badge label="🌀 Вакуум" blue />}
        {a.atex_rated    && <Badge label="⚡ ATEX" yellow />}
        {a.ce_certified  && <Badge label="✓ CE" gray />}
      </div>

      {/* PDF source */}
      {data.source_file && (
        <div className="bg-gray-800/60 rounded-lg px-4 py-3 mb-4 flex items-center justify-between">
          <span className="text-sm text-gray-400">
            📄 <strong className="text-white">{data.source_file}</strong>
            {data.source_page && (
              <span className="ml-2 bg-gray-700 px-2 py-0.5 rounded text-xs">
                стор. {data.source_page}
              </span>
            )}
          </span>
        </div>
      )}

      {/* Related products */}
      {data.related?.length > 0 && (
        <div className="mb-4">
          <div className="text-xs text-gray-500 font-bold uppercase tracking-wider mb-2">
            Схожі позиції серії {data.series}
          </div>
          <div className="flex flex-wrap gap-2">
            {data.related.map((r: any) => (
              <span key={r.id} className="text-xs bg-gray-800 px-3 py-1 rounded-full border border-gray-700">
                {r.article || r.name.slice(0, 30)}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-3 pt-2 border-t border-gray-800">
        <button
          onClick={() => {
            onClose();
            onAskAI(`Розкажи детально про ${data.article || data.name} — характеристики, застосування, монтаж`);
          }}
          className="flex-1 bg-red-600 hover:bg-red-700 px-4 py-2.5 rounded-lg text-sm font-semibold transition"
        >
          🤖 Запитати AI про цей товар
        </button>
        <button
          onClick={onClose}
          className="px-4 py-2.5 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm transition"
        >
          Закрити
        </button>
      </div>
    </Overlay>
  );
}

function Overlay({ onClose, children }: { onClose: () => void; children: React.ReactNode }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
        {children}
      </div>
    </div>
  );
}

function Badge({ label, green, blue, yellow, gray }: {
  label: string; green?: boolean; blue?: boolean; yellow?: boolean; gray?: boolean;
}) {
  const cls = green  ? "bg-green-500/10 text-green-400 border-green-500/20"
            : blue   ? "bg-blue-500/10  text-blue-400  border-blue-500/20"
            : yellow ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
            : "bg-gray-700 text-gray-300 border-gray-600";
  return (
    <span className={`text-xs px-3 py-1 rounded-full border font-medium ${cls}`}>
      {label}
    </span>
  );
}
