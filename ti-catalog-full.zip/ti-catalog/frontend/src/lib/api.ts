import type { AIQueryResponse, FilterOptions, SearchResult } from "@/types/catalog";

const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) throw new Error(`API ${path} → ${res.status}`);
  return res.json();
}

// ── Catalog search ────────────────────────────────────────────────
export async function searchProducts(params: {
  q: string;
  category?: string;
  material?: string;
  dn_min?: number;
  dn_max?: number;
  p_min?: number;
  food?: boolean;
  vacuum?: boolean;
  page?: number;
  page_size?: number;
}): Promise<{ total: number; results: SearchResult[] }> {
  const sp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") sp.set(k, String(v));
  });
  return apiFetch(`/api/search?${sp}`);
}

// ── AI query ──────────────────────────────────────────────────────
export async function aiQuery(
  query: string,
  history: { role: string; content: string }[],
  sessionId: string,
): Promise<AIQueryResponse> {
  return apiFetch("/api/ai/query", {
    method: "POST",
    body: JSON.stringify({ query, history, session_id: sessionId }),
  });
}

// ── Filters ───────────────────────────────────────────────────────
export async function getFilters(): Promise<FilterOptions> {
  return apiFetch("/api/filters");
}

// ── Product detail ────────────────────────────────────────────────
export async function getProduct(id: string): Promise<any> {
  return apiFetch(`/api/products/${id}`);
}

// ── KB search ─────────────────────────────────────────────────────
export async function searchKB(q: string, limit = 5) {
  const sp = new URLSearchParams({ q, limit: String(limit) });
  return apiFetch(`/api/kb/search?${sp}`);
}
