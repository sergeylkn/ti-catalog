export type ConfidenceLevel = "🟢" | "🟡" | "🔴";

export interface SearchResult {
  product_id: string;
  article?: string;
  name: string;
  product_type?: string;
  brand?: string;
  series?: string;
  inner_diameter_mm?: number;
  outer_diameter_mm?: number;
  pressure_max_bar?: number;
  temp_min_c?: number;
  temp_max_c?: number;
  material_normalized: string[];
  food_approved: boolean;
  vacuum_rated: boolean;
  thread_type?: string;
  connection_type?: string;
  source_file?: string;
  source_page?: number;
  confidence_level: ConfidenceLevel;
  relevance_score: number;
  why_fits: string;
  warnings: string[];
}

export interface ParsedQuery {
  product_type?: string;
  medium?: string;
  min_pressure_bar?: number;
  inner_diameter_mm?: number;
  temp_min_c?: number;
  temp_max_c?: number;
  material?: string;
  food_approved?: boolean;
  vacuum_rated?: boolean;
  search_mode: string;
  confidence: number;
  missing_params: string[];
  clarification_needed?: string;
}

export interface AIQueryResponse {
  mode: string;
  parsed?: ParsedQuery;
  results: SearchResult[];
  kb_chunks: KBChunk[];
  html_response: string;
  confidence: number;
  took_ms: number;
}

export interface KBChunk {
  id: string;
  file_name: string;
  page_number?: number;
  section_name?: string;
  chunk_type?: string;
  chunk_text: string;
  keywords: string[];
  score: number;
}

export interface FilterOptions {
  total_products: number;
  categories: { id: number; name: string; slug: string }[];
  product_types: string[];
  materials: string[];
  thread_types: string[];
  connection_types: string[];
  pressure_range: { min: number; max: number };
  dn_range: { min: number; max: number };
  temp_range: { min: number; max: number };
  special: { food_approved: number; vacuum_rated: number };
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  html?: string;
  parsed?: ParsedQuery;
  results?: SearchResult[];
  timestamp: Date;
}
