/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        gray: {
          750: "#2d3748",
          850: "#1a202c",
          950: "#030712",
        },
      },
    },
  },
  plugins: [],
};
