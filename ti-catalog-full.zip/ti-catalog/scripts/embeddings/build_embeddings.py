"""
Embeddings Pipeline
Generates vector embeddings for:
1. Products (for semantic search in Stage C)
2. KB chunks (for semantic KB search)

Run: python scripts/embeddings/build_embeddings.py [all|products|chunks]
"""

import asyncio
import logging
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "backend"))

from sqlalchemy import select
from app.db.session import get_session
from app.db.models import Product, KBChunk

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")


def get_embedder():
    """Return embedding function. Uses OpenAI by default."""
    try:
        import openai
        client = openai.OpenAI()

        def embed_batch(texts: list[str]) -> list[list[float]]:
            texts = [t[:8000] for t in texts]
            resp = client.embeddings.create(
                model="text-embedding-3-small",
                input=texts,
            )
            return [r.embedding for r in resp.data]

        logger.info("Using OpenAI text-embedding-3-small (1536 dims)")
        return embed_batch

    except ImportError:
        logger.warning("openai not installed — using dummy embeddings (all zeros)")

        def dummy_embed(texts: list[str]) -> list[list[float]]:
            return [[0.0] * 1536 for _ in texts]

        return dummy_embed


async def embed_products(batch_size: int = 50):
    """Generate embeddings for all products that don't have one yet."""
    embed = get_embedder()

    async with get_session() as db:
        stmt = (
            select(Product)
            .where(Product.embedding == None)
            .where(Product.is_active == True)
        )
        products = (await db.execute(stmt)).scalars().all()
        logger.info(f"Products to embed: {len(products)}")

        for i in range(0, len(products), batch_size):
            batch = products[i:i + batch_size]
            texts = [
                f"{p.name} {p.product_type or ''} {p.short_description or ''} {p.series or ''}"
                for p in batch
            ]
            try:
                embeddings = embed(texts)
                for product, emb in zip(batch, embeddings):
                    product.embedding = emb
                await db.flush()
                logger.info(f"  Products {i}–{i + len(batch)} embedded")
            except Exception as e:
                logger.error(f"  Batch {i} failed: {e}")

        await db.commit()
        logger.info("✅ Product embeddings done")


async def embed_chunks(batch_size: int = 100):
    """Generate embeddings for all KB chunks that don't have one yet."""
    embed = get_embedder()

    async with get_session() as db:
        stmt = select(KBChunk).where(KBChunk.embedding == None)
        chunks = (await db.execute(stmt)).scalars().all()
        logger.info(f"Chunks to embed: {len(chunks)}")

        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            texts = [c.chunk_text[:2000] for c in batch]
            try:
                embeddings = embed(texts)
                for chunk, emb in zip(batch, embeddings):
                    chunk.embedding = emb
                await db.flush()
                logger.info(f"  Chunks {i}–{i + len(batch)} embedded")
            except Exception as e:
                logger.error(f"  Batch {i} failed: {e}")

        await db.commit()
        logger.info("✅ Chunk embeddings done")


async def run_embedding_pipeline(mode: str = "all"):
    if mode in ("all", "products"):
        await embed_products()
    if mode in ("all", "chunks"):
        await embed_chunks()


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    asyncio.run(run_embedding_pipeline(mode))
