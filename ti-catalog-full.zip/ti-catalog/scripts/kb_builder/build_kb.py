"""
Knowledge Base Builder
After PDF import, this script enriches the KB chunks:
1. Extracts keywords from each chunk
2. Generates chunk summaries  
3. Links chunks to related products
4. Marks chunk types (table / specs / note / description)

Run: python scripts/kb_builder/build_kb.py
"""

import asyncio
import logging
import sys
import re
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "backend"))

from sqlalchemy import select
from app.db.session import get_session
from app.db.models import KBChunk, Product

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

# Technical terms worth extracting as keywords
TECH_TERMS = [
    r"\bEPDM\b", r"\bNBR\b", r"\bPTFE\b", r"\bPVC\b", r"\bFKM\b",
    r"\bBSP\b", r"\bBSPT\b", r"\bNPT\b", r"\bDIN\b", r"\bISO\b",
    r"\bDN\d+\b", r"\b\d+\s*bar\b", r"\b\d+\s*бар\b",
    r"\bCAMLOCK\b", r"\bStorz\b", r"\bGuillemin\b",
    r"\bFDA\b", r"\bNSF\b", r"\bATEX\b", r"\bCE\b",
    r"\bвакуум\w*", r"\bvacuum\b",
    r"\bхарч\w+", r"\bfood\b",
]


def extract_keywords(text: str) -> list[str]:
    """Extract technical keywords from chunk text."""
    found = set()
    for pattern in TECH_TERMS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches:
            found.add(m.strip().upper())
    return sorted(found)[:20]


def detect_chunk_type(text: str) -> str:
    """Detect type of chunk content."""
    if text.count("|") > 5 or re.search(r"\t.+\t", text):
        return "table"
    if re.search(r"\d+\s*(bar|бар|PSI|°C|мм|mm|DN|kg|кг)", text):
        return "specs"
    if re.search(r"(примечание|note|важно|важливо|attention|warning)", text, re.I):
        return "note"
    if re.search(r"(применение|application|застосування|призначен)", text, re.I):
        return "description"
    if re.search(r"(монтаж|установка|install|assembly)", text, re.I):
        return "installation"
    return "text"


async def link_chunks_to_products(db, chunk: KBChunk, products: list[Product]) -> list:
    """Find products mentioned in this chunk by article number."""
    if not chunk.chunk_text:
        return []

    related = []
    for p in products:
        art = p.article or p.sku or ""
        if art and len(art) > 3 and art in chunk.chunk_text:
            related.append(p.id)

    return related[:10]  # max 10 links per chunk


async def build_kb(batch_size: int = 200):
    """Enrich all KB chunks with keywords, types, and product links."""
    async with get_session() as db:
        # Load all products for linking
        products = (await db.execute(select(Product).where(Product.is_active == True))).scalars().all()
        logger.info(f"Loaded {len(products)} products for linking")

        # Load all chunks
        chunks = (await db.execute(select(KBChunk))).scalars().all()
        logger.info(f"Processing {len(chunks)} chunks")

        for i, chunk in enumerate(chunks):
            # Skip if already enriched
            if chunk.keywords:
                continue

            chunk.keywords  = extract_keywords(chunk.chunk_text)
            chunk.chunk_type = detect_chunk_type(chunk.chunk_text)

            related = await link_chunks_to_products(db, chunk, products)
            if related:
                chunk.related_product_ids = related

            if (i + 1) % batch_size == 0:
                await db.flush()
                logger.info(f"  {i + 1}/{len(chunks)} chunks processed")

        await db.commit()
        logger.info("✅ KB build complete")


if __name__ == "__main__":
    asyncio.run(build_kb())
