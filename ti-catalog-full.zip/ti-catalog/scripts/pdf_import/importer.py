"""
PDF Import Pipeline
Stage 1: Extract text + tables from PDF
Stage 2: Extract product cards (structured data)
Stage 3: Normalize all parameters
Stage 4: Save to PostgreSQL
"""

import asyncio
import logging
import re
from pathlib import Path
from typing import Optional
import pdfplumber
import anthropic
import json
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.session import get_session
from app.db.models import Product, ProductAttribute, KBDocument, ImportLog
from scripts.pdf_import.normalizer import normalize_product

logger = logging.getLogger(__name__)
ai = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)


EXTRACT_SYSTEM = """You are a technical data extractor for an industrial product catalog PDF.
Extract ALL product entries from the provided PDF page text.
Output ONLY a valid JSON array. No markdown, no explanation.

For each product found, output:
{
  "name": "product name",
  "article": "article/SKU code",
  "description": "short description",
  "product_type": "hose|fitting|valve|compensator|gauge|hydraulics|pneumatics|accessory",
  "material": "raw material string from text",
  "pressure_raw": "e.g. 16 bar, 232 PSI",
  "pressure_max_bar": number_or_null,
  "temp_raw": "e.g. -20 to 90°C",
  "temp_min_c": number_or_null,
  "temp_max_c": number_or_null,
  "diameter_raw": "e.g. DN25, 1 inch, 25mm",
  "inner_diameter_mm": number_or_null,
  "outer_diameter_mm": number_or_null,
  "thread_type": "BSP|BSPT|NPT|metric|JIC|DIN|GOST|null",
  "thread_size_raw": "e.g. 1/2 BSP",
  "connection_type": "e.g. CAMLOCK, Storz, TW, flanged",
  "standard": "e.g. DIN EN 853, ISO 6945",
  "medium": "raw medium string",
  "medium_normalized": ["air","water","oil","steam","food","acid","fuel","gas"],
  "material_normalized": ["EPDM","NBR","PTFE","PVC","Viton","SBR","stainless","brass"],
  "food_approved": true_or_false,
  "vacuum_rated": true_or_false,
  "atex_rated": true_or_false,
  "source_section": "section name if visible"
}

CRITICAL RULES:
- Extract ONLY data explicitly present in the text
- NEVER invent or assume values
- If a value is absent, use null — not zero, not a guess
- For pressure: convert PSI to bar (1 PSI = 0.0689 bar)
- For diameter: extract mm value; 1 inch = 25.4mm
- food_approved = true only if "food", "FDA", "NSF", "1-x", "харч" explicitly stated
- vacuum_rated = true only if "vacuum", "вакуум" explicitly stated"""


class PDFImporter:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def import_pdf(self, pdf_path: Path) -> dict:
        """Import a single PDF file — extract products and create KB document."""
        log = ImportLog(file_name=pdf_path.name, status="started")
        self.db.add(log)
        await self.db.flush()

        try:
            # 1. Extract text page by page
            pages = self._extract_pages(pdf_path)
            logger.info(f"{pdf_path.name}: {len(pages)} pages extracted")

            # 2. Create KB document record
            kb_doc = KBDocument(
                file_name=pdf_path.name,
                page_count=len(pages),
                extracted_text="\n\n".join(p["text"] for p in pages),
                status="processing",
            )
            self.db.add(kb_doc)
            await self.db.flush()

            # 3. Extract products from pages (in batches to save API calls)
            products_saved = 0
            for batch_start in range(0, len(pages), 3):
                batch = pages[batch_start:batch_start + 3]
                batch_text = "\n\n".join(
                    f"=== PAGE {p['page']} ===\n{p['text']}"
                    for p in batch
                )
                if len(batch_text.strip()) < 50:
                    continue

                products = await self._extract_products(
                    batch_text,
                    pdf_path.name,
                    batch[0]["page"],
                )
                for prod_data in products:
                    await self._save_product(prod_data, pdf_path.name, batch[0]["page"])
                    products_saved += 1

            # 4. Create KB chunks
            chunks_created = await self._chunk_document(kb_doc, pages)

            kb_doc.status = "done"
            log.status = "completed"
            log.products_saved = products_saved
            log.chunks_created = chunks_created
            await self.db.commit()

            return {
                "file": pdf_path.name,
                "pages": len(pages),
                "products": products_saved,
                "chunks": chunks_created,
            }

        except Exception as e:
            logger.error(f"Import failed for {pdf_path.name}: {e}")
            log.status = "failed"
            log.errors = [str(e)]
            await self.db.commit()
            raise

    def _extract_pages(self, pdf_path: Path) -> list[dict]:
        """Extract text from each page using pdfplumber."""
        pages = []
        try:
            with pdfplumber.open(pdf_path) as pdf:
                for i, page in enumerate(pdf.pages, 1):
                    text = page.extract_text() or ""
                    # Also extract tables
                    tables = page.extract_tables() or []
                    table_text = ""
                    for table in tables:
                        for row in table:
                            if row:
                                table_text += " | ".join(
                                    str(c or "") for c in row
                                ) + "\n"

                    combined = text
                    if table_text:
                        combined += f"\n\n--- TABLE ---\n{table_text}"

                    if combined.strip():
                        pages.append({
                            "page": i,
                            "text": combined[:4000],  # limit per page
                        })
        except Exception as e:
            logger.error(f"PDF extraction error: {e}")
        return pages

    async def _extract_products(
        self,
        text: str,
        source_file: str,
        start_page: int,
    ) -> list[dict]:
        """Use Claude to extract structured product data from text."""
        try:
            resp = ai.messages.create(
                model="claude-haiku-4-5",  # Use Haiku for cost efficiency on extraction
                max_tokens=4000,
                system=EXTRACT_SYSTEM,
                messages=[{"role": "user", "content": text}],
            )
            raw = resp.content[0].text.strip()
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            data = json.loads(raw)
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                return [data]
            return []
        except json.JSONDecodeError:
            logger.warning(f"JSON parse failed for {source_file} p.{start_page}")
            return []
        except Exception as e:
            logger.error(f"AI extraction error: {e}")
            return []

    async def _save_product(
        self,
        data: dict,
        source_file: str,
        source_page: int,
    ) -> Optional[Product]:
        """Save extracted product to DB, skip if no meaningful data."""
        data = normalize_product(data)
        name = (data.get("name") or "").strip()
        article = (data.get("article") or "").strip()

        if not name and not article:
            return None  # Skip empty records

        product = Product(
            name=name or article,
            article=article or None,
            sku=article or None,
            product_type=data.get("product_type"),
            short_description=data.get("description"),
            source_file=source_file,
            source_page=source_page,
            source_section=data.get("source_section"),
            raw_text_fragment=data.get("_raw_text"),
        )
        self.db.add(product)
        await self.db.flush()

        # Save attributes
        attrs = ProductAttribute(
            product_id=product.id,
            pressure_raw=data.get("pressure_raw"),
            pressure_max_bar=data.get("pressure_max_bar"),
            temp_raw=data.get("temp_raw"),
            temp_min_c=data.get("temp_min_c"),
            temp_max_c=data.get("temp_max_c"),
            diameter_raw=data.get("diameter_raw"),
            inner_diameter_mm=data.get("inner_diameter_mm"),
            outer_diameter_mm=data.get("outer_diameter_mm"),
            thread_type=data.get("thread_type"),
            thread_size_raw=data.get("thread_size_raw"),
            connection_type=data.get("connection_type"),
            standard=data.get("standard"),
            medium=data.get("medium"),
            medium_normalized=data.get("medium_normalized") or [],
            material_inner=data.get("material"),
            material_normalized=data.get("material_normalized") or [],
            food_approved=bool(data.get("food_approved")),
            vacuum_rated=bool(data.get("vacuum_rated")),
            atex_rated=bool(data.get("atex_rated")),
        )
        self.db.add(attrs)
        return product

    async def _chunk_document(
        self,
        doc: KBDocument,
        pages: list[dict],
    ) -> int:
        """Split document into searchable chunks for the knowledge base."""
        from app.db.models import KBChunk

        chunk_size = settings.CHUNK_SIZE
        overlap    = settings.CHUNK_OVERLAP
        count = 0

        for page_data in pages:
            text = page_data["text"]
            page_no = page_data["page"]

            # Split into overlapping chunks
            start = 0
            chunk_idx = 0
            while start < len(text):
                end = start + chunk_size
                chunk_text = text[start:end]

                if len(chunk_text.strip()) < 30:
                    break

                # Detect chunk type
                chunk_type = self._detect_chunk_type(chunk_text)

                chunk = KBChunk(
                    document_id=doc.id,
                    file_name=doc.file_name,
                    page_number=page_no,
                    chunk_index=chunk_idx,
                    chunk_text=chunk_text,
                    chunk_type=chunk_type,
                    char_count=len(chunk_text),
                    token_estimate=len(chunk_text) // 4,
                )
                self.db.add(chunk)
                count += 1
                chunk_idx += 1
                start = end - overlap
                if start >= len(text):
                    break

        return count

    def _detect_chunk_type(self, text: str) -> str:
        """Detect if chunk is a table, specs section, note, etc."""
        if "|" in text and text.count("|") > 5:
            return "table"
        if re.search(r"\d+\s*(bar|бар|PSI|°C|мм|mm|DN)", text):
            return "specs"
        if re.search(r"(примечание|note|важно|важливо|attention)", text, re.I):
            return "note"
        if re.search(r"(применение|application|застосування)", text, re.I):
            return "description"
        return "text"


async def import_all_pdfs(pdf_dir: Path):
    """Import all PDFs from a directory."""
    pdf_files = sorted(pdf_dir.glob("*.pdf"))
    logger.info(f"Found {len(pdf_files)} PDFs in {pdf_dir}")

    async with get_session() as db:
        importer = PDFImporter(db)
        results = []
        for pdf in pdf_files:
            logger.info(f"Importing: {pdf.name}")
            try:
                r = await importer.import_pdf(pdf)
                results.append(r)
                logger.info(f"  → {r}")
            except Exception as e:
                logger.error(f"  → FAILED: {e}")
                results.append({"file": pdf.name, "error": str(e)})

    return results


if __name__ == "__main__":
    import sys
    pdf_dir = Path(sys.argv[1] if len(sys.argv) > 1 else settings.PDF_DIR)
    asyncio.run(import_all_pdfs(pdf_dir))
