"""
Parameter Normalizer
Converts raw text values extracted from PDFs into normalized numeric values.

Examples:
  "16 bar / 232 PSI"  → pressure_max_bar=16.0
  "-20 до +90°C"      → temp_min_c=-20, temp_max_c=90
  "DN 25 / 1 inch"   → inner_diameter_mm=25.0
  "1/2 BSP"          → thread_type="BSP", thread_size_raw="1/2 BSP"
"""

import re
from typing import Optional


# ── Pressure ─────────────────────────────────────────────────────────────────

def normalize_pressure(raw: str) -> Optional[float]:
    """Extract max pressure in bar from raw string."""
    if not raw:
        return None
    raw = raw.strip()

    # Direct bar value: "16 bar", "16.0 bar", "16 бар"
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:bar|бар)", raw, re.IGNORECASE)
    if m:
        return float(m.group(1))

    # PSI: "232 PSI", "232psi"
    m = re.search(r"(\d+(?:\.\d+)?)\s*psi", raw, re.IGNORECASE)
    if m:
        return round(float(m.group(1)) * 0.0689476, 2)

    # MPa: "1.6 MPa"
    m = re.search(r"(\d+(?:\.\d+)?)\s*mpa", raw, re.IGNORECASE)
    if m:
        return round(float(m.group(1)) * 10, 2)

    # atm: "10 atm", "10 атм"
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:atm|атм)", raw, re.IGNORECASE)
    if m:
        return round(float(m.group(1)) * 1.01325, 2)

    return None


# ── Temperature ───────────────────────────────────────────────────────────────

def normalize_temperature(raw: str) -> tuple[Optional[float], Optional[float]]:
    """Extract (temp_min_c, temp_max_c) from raw string."""
    if not raw:
        return None, None

    # Range: "-20 to +90°C", "-20...+90", "-20÷+90", "-20 до +90"
    m = re.search(
        r"([+-]?\d+(?:\.\d+)?)\s*(?:to|до|\.{2,3}|÷|–|-)\s*([+-]?\d+(?:\.\d+)?)\s*°?[Cc]",
        raw,
    )
    if m:
        return float(m.group(1)), float(m.group(2))

    # Single value: "max 120°C", "до 90°C", "+90°C"
    m = re.search(r"([+-]?\d+(?:\.\d+)?)\s*°?[Cc]", raw)
    if m:
        val = float(m.group(1))
        if val < 0:
            return val, None
        return None, val

    return None, None


# ── Diameter ──────────────────────────────────────────────────────────────────

def normalize_diameter(raw: str) -> tuple[Optional[float], Optional[str]]:
    """
    Extract (inner_diameter_mm, diameter_inch_string) from raw string.
    Returns (mm_value, inch_string).
    """
    if not raw:
        return None, None

    mm_val    = None
    inch_str  = None

    # DN notation: "DN25", "DN 25", "DN-25"
    m = re.search(r"\bDN\s*-?\s*(\d+(?:\.\d+)?)\b", raw, re.IGNORECASE)
    if m:
        mm_val = float(m.group(1))

    # Explicit mm: "25 mm", "25mm", "25,4 мм"
    if mm_val is None:
        m = re.search(r"(\d+(?:[.,]\d+)?)\s*(?:mm|мм)\b", raw, re.IGNORECASE)
        if m:
            mm_val = float(m.group(1).replace(",", "."))

    # Inch fraction: "1/2\"", "3/4 inch", "1\" ", "2 inch"
    m = re.search(r'(\d+(?:/\d+)?)\s*(?:"|inch|"|\'\')', raw, re.IGNORECASE)
    if m:
        inch_str = m.group(1)
        if mm_val is None:
            mm_val = _inch_to_mm(inch_str)

    return mm_val, inch_str


def _inch_to_mm(inch: str) -> Optional[float]:
    """Convert inch string to mm. '1/2' → 12.7, '1' → 25.4"""
    try:
        if "/" in inch:
            num, den = inch.split("/")
            return round(int(num) / int(den) * 25.4, 2)
        return round(float(inch) * 25.4, 2)
    except Exception:
        return None


# ── Thread type ───────────────────────────────────────────────────────────────

THREAD_PATTERNS = [
    (r"\bBSPT\b",   "BSPT"),
    (r"\bBSP\b",    "BSP"),
    (r"\bNPT\b",    "NPT"),
    (r"\bNPTF\b",   "NPTF"),
    (r"\bJIC\b",    "JIC"),
    (r"\bGOST\b|ГОСТ", "GOST"),
    (r"\bM\d+",     "metric"),
    (r"\bDIN\b",    "DIN"),
    (r"\bG\s*\d",   "BSP"),    # G 1/2 = BSP
    (r"\bRC\b",     "BSPT"),   # RC = BSPT (ISO 7/1)
    (r"\bRp\b",     "BSP"),    # Rp = parallel BSP
]


def normalize_thread(raw: str) -> Optional[str]:
    """Identify the thread standard from raw text."""
    if not raw:
        return None
    for pattern, thread_type in THREAD_PATTERNS:
        if re.search(pattern, raw, re.IGNORECASE):
            return thread_type
    return None


# ── Material ──────────────────────────────────────────────────────────────────

MATERIAL_PATTERNS = [
    (r"\bEPDM\b",           "EPDM"),
    (r"\bNBR\b|\bNitrile\b","NBR"),
    (r"\bPTFE\b|\bteflon\b","PTFE"),
    (r"\bFKM\b|\bViton\b",  "Viton"),
    (r"\bPVC\b",            "PVC"),
    (r"\bSBR\b",            "SBR"),
    (r"\bNeoprene\b|\bCR\b","Neoprene"),
    (r"\bSilicone\b|\bSilikon\b|\bсиліко", "Silicone"),
    (r"\bPolyurethane\b|\bPU\b|\bПоліурет","Polyurethane"),
    (r"\bPolyethylene\b|\bPE\b",          "PE"),
    (r"\bPolypropylene\b|\bPP\b",         "PP"),
    (r"\bstainless\b|\bSST\b|\bнержав",   "stainless"),
    (r"\bbrass\b|\bлатунь|\bлатун",       "brass"),
    (r"\balumini?um\b|\bалюмін",          "aluminium"),
    (r"\bsteel\b|\bсталь",               "steel"),
]


def normalize_materials(raw: str) -> list[str]:
    """Extract normalized material codes from raw text."""
    if not raw:
        return []
    found = []
    for pattern, mat in MATERIAL_PATTERNS:
        if re.search(pattern, raw, re.IGNORECASE):
            if mat not in found:
                found.append(mat)
    return found


# ── Medium ────────────────────────────────────────────────────────────────────

MEDIUM_PATTERNS = [
    (r"\b(air|повіт|воздух)\b",              "air"),
    (r"\b(water|вод[аи]|воду)\b",            "water"),
    (r"\b(oil|масл[оа]|мастил)\b",           "oil"),
    (r"\b(steam|пар[а]?)\b",                 "steam"),
    (r"\b(fuel|паливо|бензин|дизель|diesel)\b","fuel"),
    (r"\b(gas|газ[а]?)\b",                   "gas"),
    (r"\b(acid|кислот|хімі|chemical)\b",     "chemical"),
    (r"\b(food|харч|FDA|NSF|1-х|молок|пиво|вин)\b","food"),
    (r"\b(vacuum|вакуум)\b",                 "vacuum"),
    (r"\b(hydraulic|гідравл)\b",             "hydraulic"),
    (r"\b(pneumat|пневм)\b",                 "pneumatic"),
]


def normalize_medium(raw: str) -> list[str]:
    """Extract normalized medium codes from raw text."""
    if not raw:
        return []
    found = []
    for pattern, medium in MEDIUM_PATTERNS:
        if re.search(pattern, raw, re.IGNORECASE):
            if medium not in found:
                found.append(medium)
    return found


def is_food_approved(text: str) -> bool:
    """Detect food-grade approval in text."""
    # Note: \b doesn't work with Cyrillic — use separate pattern without boundary
    return bool(re.search(
        r"(FDA|NSF|food[\s-]?grade|харч|1-x|1-х|BfR|KTW)",
        text, re.IGNORECASE
    ))


def is_vacuum_rated(text: str) -> bool:
    """Detect vacuum rating in text."""
    return bool(re.search(r"\b(vacuum|вакуум)", text, re.IGNORECASE))


def is_atex_rated(text: str) -> bool:
    """Detect ATEX/explosion-proof rating."""
    return bool(re.search(r"\b(ATEX|EEx|вибухо|антистат|antistatic)\b", text, re.IGNORECASE))


# ── Full normalizer ───────────────────────────────────────────────────────────

def normalize_product(raw: dict) -> dict:
    """
    Apply all normalizers to a raw product dict extracted from PDF.
    Returns dict with normalized values ready for DB insertion.
    """
    out = dict(raw)

    # Pressure
    if not raw.get("pressure_max_bar") and raw.get("pressure_raw"):
        out["pressure_max_bar"] = normalize_pressure(raw["pressure_raw"])

    # Temperature
    if (not raw.get("temp_min_c") and not raw.get("temp_max_c")) and raw.get("temp_raw"):
        t_min, t_max = normalize_temperature(raw["temp_raw"])
        out["temp_min_c"] = t_min
        out["temp_max_c"] = t_max

    # Diameter
    if not raw.get("inner_diameter_mm") and raw.get("diameter_raw"):
        mm, inch = normalize_diameter(raw["diameter_raw"])
        out["inner_diameter_mm"] = mm
        if inch and not raw.get("diameter_inch"):
            out["diameter_inch"] = inch

    # Thread
    if not raw.get("thread_type") and raw.get("thread_size_raw"):
        out["thread_type"] = normalize_thread(raw["thread_size_raw"])

    # Materials
    if not raw.get("material_normalized"):
        src = " ".join(filter(None, [
            raw.get("material"), raw.get("material_inner"),
            raw.get("material_outer"), raw.get("description"),
        ]))
        out["material_normalized"] = normalize_materials(src)

    # Medium
    if not raw.get("medium_normalized"):
        src = " ".join(filter(None, [raw.get("medium"), raw.get("description")]))
        out["medium_normalized"] = normalize_medium(src)

    # Flags
    full_text = " ".join(str(v) for v in raw.values() if v)
    if raw.get("food_approved") is None:
        out["food_approved"] = is_food_approved(full_text)
    if raw.get("vacuum_rated") is None:
        out["vacuum_rated"] = is_vacuum_rated(full_text)
    if raw.get("atex_rated") is None:
        out["atex_rated"] = is_atex_rated(full_text)

    return out
