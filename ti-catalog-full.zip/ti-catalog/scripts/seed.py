"""
Seed Script
Populates the database with:
1. Default category tree (from Tubes International catalog structure)
2. Default compatibility rules

Run: python scripts/seed.py
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))

from app.db.session import get_session
from app.db.models import Category, CompatibilityRule


# ── Category tree (matches Tubes International catalog sections) ─────────────

CATEGORIES = [
    # (slug, name, parent_slug, sort_order)
    ("hoses",          "Промислові шланги",          None,       1),
    ("hoses-air",      "Шланги для повітря",          "hoses",    1),
    ("hoses-water",    "Шланги для води",             "hoses",    2),
    ("hoses-steam",    "Шланги для пару",             "hoses",    3),
    ("hoses-food",     "Харчові шланги",              "hoses",    4),
    ("hoses-chemical", "Хімічні шланги",              "hoses",    5),
    ("hoses-oil",      "Шланги для масел/палива",     "hoses",    6),

    ("hydraulics",     "Силова гідравліка",           None,       2),
    ("hyd-hoses",      "Гідравлічні рукави",          "hydraulics", 1),
    ("hyd-fittings",   "Гідравлічні фітинги",         "hydraulics", 2),
    ("hyd-accessories","Аксесуари гідравліки",         "hydraulics", 3),

    ("pneumatics",     "Промислова пневматика",       None,       3),
    ("pneu-hoses",     "Пневматичні шланги",          "pneumatics", 1),
    ("pneu-fittings",  "Пневматичні фітинги",         "pneumatics", 2),

    ("fittings",       "Промислова арматура",         None,       4),
    ("fit-camlock",    "CAMLOCK з'єднання",           "fittings", 1),
    ("fit-storz",      "Storz з'єднання",             "fittings", 2),
    ("fit-guillemin",  "Guillemin з'єднання",         "fittings", 3),
    ("fit-tw",         "TW з'єднання",                "fittings", 4),
    ("fit-flanges",    "Фланцеві з'єднання",          "fittings", 5),
    ("fit-hose-tails", "Ніпелі та хомути",            "fittings", 6),

    ("precision",      "Прецизійна арматура",         None,       5),
    ("prec-valves",    "Клапани та крани",            "precision",1),
    ("prec-gauges",    "Манометри та датчики",        "precision",2),

    ("compensators",   "Компенсатори",                None,       6),
    ("comp-rubber",    "Гумові компенсатори",         "compensators", 1),
    ("comp-metal",     "Металеві компенсатори",       "compensators", 2),
    ("comp-ptfe",      "PTFE компенсатори",           "compensators", 3),

    ("accessories",    "Пристрої та аксесуари",       None,       7),
    ("acc-protection", "Засоби захисту",              "accessories", 1),
    ("acc-chemical",   "Хімічна продукція",           "accessories", 2),
]

# ── Compatibility rules ──────────────────────────────────────────────────────

COMPAT_RULES = [
    {
        "name":        "no_hydraulics_for_pneumatics",
        "description": "Не підбирати гідравліку коли запитано пневматику",
        "rule_type":   "exclude",
        "priority":    100,
        "condition":   {"query_type": "pneumatics"},
        "action":      {"exclude_category": "hydraulics"},
    },
    {
        "name":        "no_pneumatics_for_hydraulics",
        "description": "Не підбирати пневматику коли запитано гідравліку",
        "rule_type":   "exclude",
        "priority":    100,
        "condition":   {"query_type": "hydraulics"},
        "action":      {"exclude_category": "pneumatics"},
    },
    {
        "name":        "no_compensators_for_hoses",
        "description": "Не підбирати компенсатори коли запитано шланг",
        "rule_type":   "exclude",
        "priority":    90,
        "condition":   {"query_type": "hose"},
        "action":      {"exclude_category": "compensators"},
    },
    {
        "name":        "no_accessories_for_main_products",
        "description": "Аксесуари не замінюють основний товар",
        "rule_type":   "exclude",
        "priority":    80,
        "condition":   {"query_type": ["hose", "fitting", "valve", "hydraulics", "pneumatics"]},
        "action":      {"exclude_category": "accessories"},
    },
    {
        "name":        "pressure_warning",
        "description": "Попередження якщо тиск товару не вказаний",
        "rule_type":   "warn",
        "priority":    50,
        "condition":   {"pressure_requested": True, "product_pressure": None},
        "action":      {"warning": "Максимальний тиск не вказаний — уточніть у постачальника"},
    },
    {
        "name":        "food_strict",
        "description": "Для харчових застосувань — тільки сертифіковані товари",
        "rule_type":   "warn",
        "priority":    95,
        "condition":   {"food_required": True, "product_food": False},
        "action":      {"warning": "Товар не має харчового сертифікату (FDA/NSF)"},
    },
    {
        "name":        "steam_temp_check",
        "description": "Для пару — перевірити температурний діапазон",
        "rule_type":   "warn",
        "priority":    85,
        "condition":   {"medium": "steam", "temp_max_c": {"lt": 120}},
        "action":      {"warning": "Для пару потрібна T ≥ 120°C — перевірте температурний діапазон товару"},
    },
]


async def seed():
    async with get_session() as db:
        # ── Categories ────────────────────────────────────────────────
        slug_to_id: dict[str, int] = {}

        for slug, name, parent_slug, sort in CATEGORIES:
            # Check if exists
            from sqlalchemy import select
            existing = (await db.execute(
                select(Category).where(Category.slug == slug)
            )).scalar_one_or_none()

            if existing:
                slug_to_id[slug] = existing.id
                continue

            parent_id = slug_to_id.get(parent_slug) if parent_slug else None
            cat = Category(
                slug=slug, name=name,
                parent_id=parent_id,
                sort_order=sort,
            )
            db.add(cat)
            await db.flush()
            slug_to_id[slug] = cat.id

        print(f"✅ Categories: {len(slug_to_id)} seeded")

        # ── Compatibility rules ───────────────────────────────────────
        from sqlalchemy import select as sel
        count = 0
        for rule_data in COMPAT_RULES:
            existing = (await db.execute(
                sel(CompatibilityRule).where(CompatibilityRule.name == rule_data["name"])
            )).scalar_one_or_none()
            if existing:
                continue

            rule = CompatibilityRule(**rule_data)
            db.add(rule)
            count += 1

        print(f"✅ Compatibility rules: {count} seeded")
        await db.commit()
        print("✅ Seed complete")


if __name__ == "__main__":
    asyncio.run(seed())
